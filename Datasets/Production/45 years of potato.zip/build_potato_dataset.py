import json, os, re
import numpy as np, pandas as pd
from parse_potato import main as parse_pdf

OUT = "/mnt/user-data/outputs"
os.makedirs(OUT, exist_ok=True)
ACRE_TO_HA = 0.40468564224
VARS = ["local", "hyv", "indian", "total"]
RAW = [f"{v}_{q}" for v in VARS for q in ("area", "prod")]

df, aud = parse_pdf()
df = df.sort_values("row_order", kind="stable").reset_index(drop=True)
df["dq_flags"] = df.dq_flags.apply(list)
def flag(mask, text):
    for i in df.index[mask]: df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [text]

# ------------------------------------------------------------------ names / years / systems
STD = {"Bakergonj": "Barisal", "Chittagonj": "Chittagong", "Kustia": "Kushtia", "Mymenshing": "Mymensingh", "Kishoregonj": "Kishoreganj",
       "Sunamgonj": "Sunamganj", "Hobigonj": "Habiganj", "Maulavibazar": "Moulvibazar", "Manikgonj": "Manikganj", "Munsigonj": "Munshiganj",
       "Narayangonj": "Narayanganj", "Gopalgonj": "Gopalganj", "Perojpur": "Pirojpur", "Noagaon": "Naogaon", "Nawabgonj": "Nawabganj",
       "Sirajgonj": "Sirajganj", "Jalakati": "Jhalokati", "jamalpur": "Jamalpur", "Jhalakathi": "Jhalokati", "Gaibanda": "Gaibandha", "BANGLADESH": "Bangladesh", "Bangladesh": "Bangladesh"}
def std_name(n):
    n = re.sub(r"\s+", " ", n).strip(); k = re.sub(r"[\s\.]", "", n).lower()
    if k in ("chittagonght", "chittagongh t"): return "Chittagong Hill Tracts"
    if k.startswith("chittagonght"): return "Chittagong Hill Tracts"
    return STD.get(n, n)
df["year_start"] = df.fiscal_year.str[:4].astype(int)
df["district_system"] = np.where(df.year_start < 1979, "20/21-district", np.where(df.year_start < 2003, "23-district", "64-district"))
df["has_variety_cols"] = df.era != "A"           # Local / HYV / Indian printed separately from 1982-83; before that one series
df["district_std"] = df.district_raw.map(std_name)

# ------------------------------------------------------------------ geography
G23 = {
 "Bandarban": ["Bandarban"], "Chittagong": ["Chittagong", "Cox's Bazar"], "Comilla": ["Comilla", "Chandpur", "Brahmanbaria"],
 "Khagrachari": ["Khagrachari"], "Noakhali": ["Noakhali", "Lakshmipur", "Feni"], "Rangamati": ["Rangamati"],
 "Sylhet": ["Sylhet", "Moulvibazar", "Sunamganj", "Habiganj"],
 "Dhaka": ["Dhaka", "Gazipur", "Manikganj", "Munshiganj", "Narayanganj", "Narsingdi"],
 "Faridpur": ["Faridpur", "Rajbari", "Madaripur", "Gopalganj", "Shariatpur"], "Jamalpur": ["Jamalpur", "Sherpur"],
 "Kishoreganj": ["Kishoreganj", "Netrokona"], "Mymensingh": ["Mymensingh"], "Tangail": ["Tangail"],
 "Barisal": ["Barisal", "Jhalokati", "Pirojpur", "Bhola"], "Jessore": ["Jessore", "Jhenaidah", "Magura", "Narail"],
 "Khulna": ["Khulna", "Bagerhat", "Satkhira"], "Kushtia": ["Kushtia", "Chuadanga", "Meherpur"],
 "Patuakhali": ["Patuakhali", "Barguna"], "Bogra": ["Bogra", "Joypurhat"], "Dinajpur": ["Dinajpur", "Thakurgaon", "Panchagar"],
 "Pabna": ["Pabna", "Sirajganj"], "Rajshahi": ["Rajshahi", "Naogaon", "Natore", "Nawabganj"],
 "Rangpur": ["Rangpur", "Gaibandha", "Kurigram", "Nilphamari", "Lalmonirhat"]}
D2G = {d: g for g, ds in G23.items() for d in ds}; assert len(D2G) == 64
HILL = {"Bandarban", "Khagrachari", "Rangamati", "Chittagong Hill Tracts"}

# ------------------------------------------------------------------ row types
df["row_type"] = "district"; df["sl"] = df.sl_no.fillna("")
for fy, g in df.groupby("fiscal_year", sort=False):
    g = g.sort_values("row_order"); acc = []
    for i, r in g.iterrows():
        n = r.district_std; low = n.lower()
        if low.startswith("bangladesh"): df.at[i, "row_type"] = "national_total"; continue
        if r.year_start >= 2013:
            if "division" in low or re.fullmatch(r"0[1-7]", r.sl) or (r.year_start == 2014 and "division" in low): df.at[i, "row_type"] = "division_subtotal"
            continue
        if r.year_start >= 2003 and low.endswith(" region"):
            base = STD.get(n[:-7], n[:-7])
            if any(D2G.get(df.at[j, "district_std"]) == base for j in acc):
                df.at[i, "row_type"] = "region_subtotal"; df.at[i, "district_std"] = base + " Region"
                df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + []
                members = [df.at[j, "district_std"] for j in acc if D2G.get(df.at[j, "district_std"]) == base]
                assert set(members) == set(G23[base]), (fy, base, members)          # PDF's own region grouping == my mapping
            else:
                df.at[i, "district_std"] = base; df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["district_printed_as_single_district_region_row"]
                acc.append(i); continue
            acc = []
        else: acc.append(i)
# 'Tangail Region' in 2013-14 is a district; division names normalised
m = (df.year_start >= 2013) & (df.row_type == "district") & df.district_std.str.endswith(" Region")
df.loc[m, "district_std"] = df.loc[m, "district_std"].str.replace(" Region", "", regex=False)
flag(m, "label_note_district_printed_with_Region_suffix")
m = df.row_type == "division_subtotal"
df.loc[m, "district_std"] = df.loc[m, "district_std"].str.replace(" Region", " Division", regex=False)
# divisions from the 2013-14 table (division rows follow their districts; 7-division scheme)
t = df[df.fiscal_year == "2013-14"].sort_values("row_order")
div, pend = {}, []
for _, r in t.iterrows():
    if r.row_type == "district": pend.append(r.district_std)
    elif r.row_type == "division_subtotal":
        for d in pend: div[d] = r.district_std.replace(" Division", "")
        pend = []
assert len(div) == 64, len(div)
G2DIV = {}
for g, ds in G23.items():
    s = {div[d] for d in ds}; assert len(s) == 1, (g, s); G2DIV[g] = s.pop()
def division_of(r):
    if r.row_type != "district": return np.nan
    if r.district_system == "64-district": return div[r.district_std]
    return G2DIV.get(r.district_std, "Chittagong" if r.district_std == "Chittagong Hill Tracts" else np.nan)
def group_of(r):
    if r.row_type != "district": return np.nan
    return D2G[r.district_std] if r.district_system == "64-district" else r.district_std
df["division"] = df.apply(division_of, axis=1); df["legacy_group_23"] = df.apply(group_of, axis=1)
cnt = df[df.row_type == "district"].groupby("fiscal_year").size()
print("district rows per year:", cnt.value_counts().to_dict())
assert (cnt[cnt.index >= "2003-04"] == 64).all()

# ------------------------------------------------------------------ clean columns
for c in RAW: df[f"{c}_clean"] = df[c].astype(float)
dist = df.row_type == "district"
df["label_repaired"] = False; df["label_repair_note"] = ""

# R1. 2013-14: Local / HYV / Total do not add up and do not match neighbouring years for the Chittagong, Sylhet and Dhaka blocks
t = df[(df.fiscal_year == "2013-14")].sort_values("row_order")
last = t.index[t.district_std == "Dhaka Division"][0]; first = t.index[0]
blk = [i for i in t.index if t.index.get_loc(i) <= t.index.get_loc(last) and df.at[i, "row_type"] in ("district", "division_subtotal")]
assert len(blk) == 35, len(blk)                      # 32 districts + 3 division rows
for i in blk:
    for c in RAW: df.at[i, f"{c}_clean"] = np.nan
    df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["suspect_unrecoverable_2013_14_columns_inconsistent_nulled"]

# R2. typos: neighbour-year yield test (digit shift x10 / :10, or a stray trailing digit), else NULL
NB_VARS = lambda era: ["total"] if era == "A" else ["local", "hyv", "indian"]
def nb_vals(i, v):
    r = df.loc[i]; out = []
    for dy in (-1, 1):
        j = df.index[(df.district_std == r.district_std) & (df.district_system == r.district_system) & (df.year_start == r.year_start + dy) & (df.row_type == "district")]
        if len(j):
            a, p = df.at[j[0], f"{v}_area_clean"], df.at[j[0], f"{v}_prod_clean"]
            if pd.notna(a) and pd.notna(p) and a > 0 and p > 0: out.append((a, p))
    if len(out) == 2 and abs(np.log((out[0][1] / out[0][0]) / (out[1][1] / out[1][0]))) > 0.25: return []
    return out
repairs = []
MINA = {"total": 300, "local": 300, "hyv": 300, "indian": 100}
for pass_no, v in [(pn, vv) for pn in (1, 2) for vv in ["total", "local", "hyv", "indian"]]:
    a, p = f"{v}_area_clean", f"{v}_prod_clean"
    y = df[p] / df[a].where(df[a] > 0)
    med = y[dist].groupby(df.fiscal_year[dist]).median(); rel = y / df.fiscal_year.map(med)
    for i in df.index[dist & df[a].notna() & df[p].notna() & (df[a] > 0)]:
        if v not in NB_VARS(df.at[i, "era"]): continue
        A, P = df.at[i, a], df.at[i, p]
        if A < MINA[v]: continue
        nbs = nb_vals(i, v)
        extreme = (rel[i] < 0.3) or (rel[i] > 3.0)
        anomaly = False
        if len(nbs) == 2 and A >= 1000:
            nby = np.mean([pp / aa for aa, pp in nbs])
            if not (0.5 <= (P / A) / nby <= 1.8):
                dA = min(abs(np.log(A / aa)) for aa, _ in nbs); dP = min(abs(np.log(P / pp)) for _, pp in nbs)
                anomaly = max(dA, dP) > 0.35 and min(dA, dP) < 0.25
        if pass_no == 1 and not extreme: continue
        if pass_no == 2 and not (anomaly and not extreme): continue
        dA = min(abs(np.log(A / aa)) for aa, _ in nbs) if nbs else 0; dP = min(abs(np.log(P / pp)) for _, pp in nbs) if nbs else 0
        which = "area" if dA > dP else "prod"
        ref = np.mean([pp / aa for aa, pp in nbs]) if nbs else float(med[df.at[i, "fiscal_year"]])
        opts = ([("area_x10", A * 10, P), ("area_div10", A / 10, P), ("area_drop_last_digit", A // 10 if A % 10 == 5 else np.nan, P)] if which == "area"
                else [("prod_x10", A, P * 10), ("prod_div10", A, P / 10)])
        good = []
        for lab, na, np_ in opts:
            if pd.isna(na) or na != int(na) or np_ != int(np_): continue
            if not (0.6 * ref <= np_ / na <= 1.5 * ref): continue
            val, nbq = (na, [aa for aa, _ in nbs]) if which == "area" else (np_, [pp for _, pp in nbs])
            good.append((min(abs(np.log(val / n)) for n in nbq) if nbq else np.inf, lab, na, np_))
        good.sort()
        if good and good[0][0] < np.log(1.3):
            _, lab, na, np_ = good[0]; df.at[i, a], df.at[i, p] = na, np_
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"adj_{v}_{lab}"]; repairs.append((df.at[i, "fiscal_year"], df.at[i, "district_std"], v, lab, A, P, na, np_))
        else:
            df.at[i, a] = np.nan; df.at[i, p] = np.nan
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"suspect_unrecoverable_{v}_nulled"]; repairs.append((df.at[i, "fiscal_year"], df.at[i, "district_std"], v, "NULLED", A, P, np.nan, np.nan))
rep_tbl = pd.DataFrame(repairs, columns=["fy", "district", "variety", "action", "area_raw", "prod_raw", "area_clean", "prod_clean"])
print(rep_tbl.to_string())

# totals: with variety columns the total is the sum of the varieties (NaN propagates); before 1982-83 the single printed series is the total
for q in ("area", "prod"):
    s = df[f"local_{q}_clean"] + df[f"hyv_{q}_clean"] + df[f"indian_{q}_clean"].fillna(0).where(df.era == "B", 0)
    ok = df.has_variety_cols & ~df.fiscal_year.eq("2013-14") | (df.has_variety_cols & (df.fiscal_year == "2013-14") & df[f"local_{q}_clean"].notna())
    df.loc[ok, f"total_{q}_clean"] = s[ok]
    df.loc[df.has_variety_cols & (df[f"local_{q}_clean"].isna() | df[f"hyv_{q}_clean"].isna()), f"total_{q}_clean"] = np.nan
z = lambda c: df[c].fillna(0)
df["total_area_calc_printed"] = np.where(df.has_variety_cols, z("local_area") + z("hyv_area") + z("indian_area"), df.total_area)
df["total_prod_calc_printed"] = np.where(df.has_variety_cols, z("local_prod") + z("hyv_prod") + z("indian_prod"), df.total_prod)
df["chk_area_printed_minus_calc"] = df.total_area - df.total_area_calc_printed
df["chk_prod_printed_minus_calc"] = df.total_prod - df.total_prod_calc_printed
flag(((df.chk_area_printed_minus_calc.abs() > 1) | (df.chk_prod_printed_minus_calc.abs() > 1)) & (df.fiscal_year != "2013-14"),
     "src_printed_total_not_equal_sum_of_varieties")

# ------------------------------------------------------------------ aggregates (clean)
cols = RAW
FILL = {c: df[f"{c}_clean"].where(df[f"{c}_clean"].notna(), df[c]) for c in cols}
def agg_set(sel, i, has_variety):
    for c in cols:
        if c.startswith(("local", "hyv", "indian")) and not has_variety: continue
        if c.startswith("indian") and df.at[i, "era"] != "B": continue
        df.at[i, f"{c}_clean"] = FILL[c][sel].sum()
    for q in ("area", "prod"):
        if has_variety: df.at[i, f"total_{q}_clean"] = df.at[i, f"local_{q}_clean"] + df.at[i, f"hyv_{q}_clean"] + (df.at[i, f"indian_{q}_clean"] if df.at[i, "era"] == "B" else 0)
for fy in df.fiscal_year.unique():
    g = df[df.fiscal_year == fy]; sel = dist & (df.fiscal_year == fy)
    ni = g.index[g.row_type == "national_total"]; assert len(ni) == 1, fy
    if fy == "2013-14":
        for c in RAW: df.at[ni[0], f"{c}_clean"] = df.at[ni[0], c]            # district rows unreliable -> keep the printed national row
        df.at[ni[0], "dq_flags"] = df.at[ni[0], "dq_flags"] + ["note_2013_14_national_kept_printed_district_rows_unreliable"]
    else: agg_set(sel, ni[0], bool(df.at[ni[0], "has_variety_cols"]))
    for i in g.index[g.row_type == "division_subtotal"]:
        if fy == "2013-14" and i in blk: continue
        dn = df.at[i, "district_std"].replace(" Division", "")
        MYM = ["Jamalpur", "Sherpur", "Netrokona", "Mymensingh"]                       # 8-division scheme printed in 2014-15
        if fy >= "2014" and dn == "Mymensingh": sel2 = sel & df.district_std.isin(MYM)
        elif fy >= "2014" and dn == "Dhaka": sel2 = sel & (df.division == "Dhaka") & ~df.district_std.isin(MYM)
        else: sel2 = sel & (df.division == dn)
        agg_set(sel2, i, bool(df.at[i, "has_variety_cols"]))
    for i in g.index[g.row_type == "region_subtotal"]:
        rn = df.at[i, "district_std"].replace(" Region", ""); agg_set(sel & (df.legacy_group_23 == rn), i, bool(df.at[i, "has_variety_cols"]))
for rt, tag in (("national_total", "national"), ("division_subtotal", "division"), ("region_subtotal", "region")):
    for i in df.index[df.row_type == rt]:
        for c in cols:
            pv, cv = df.at[i, c], df.at[i, f"{c}_clean"]
            if pd.notna(pv) and pd.notna(cv) and abs(pv - cv) > 1:
                df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"src_{tag}_printed_{c}_differs_from_district_sum"]

# ------------------------------------------------------------------ source-level notes
dup_pairs = [("1993-94", "1994-95"), ("2003-04", "2004-05")]
for a_, b_ in dup_pairs: flag(df.fiscal_year.isin([a_, b_]), f"src_{a_}_and_{b_}_values_identical_one_year_is_a_copy")
flag(dist & (df.district_std == "Rangamati") & df.fiscal_year.isin(["1979-80", "1980-81", "1981-82", "1982-83", "1983-84"]), "note_cht_probably_included_in_rangamati_assumed")
flag(df.dq_flags.apply(lambda f: "cell_fragments_rejoined" in f), "note_cell_fragments_rejoined")

# ------------------------------------------------------------------ yields
def add_yields(d):
    pa = lambda p, a: np.where(d[a] > 0, d[p] / d[a], np.nan)
    d["yield_total_t_per_acre"] = pa("total_prod_clean", "total_area_clean")
    d["yield_local_t_per_acre"] = pa("local_prod_clean", "local_area_clean")
    d["yield_hyv_t_per_acre"] = pa("hyv_prod_clean", "hyv_area_clean")
    d["yield_indian_t_per_acre"] = pa("indian_prod_clean", "indian_area_clean")
    d["yield_total_kg_per_ha"] = d.yield_total_t_per_acre * 1000 / ACRE_TO_HA
    return d
df = add_yields(df)
dd = df[dist & (df.total_area_clean >= 300)]
med = dd.groupby("fiscal_year").yield_total_t_per_acre.median(); rel = dd.yield_total_t_per_acre / dd.fiscal_year.map(med)
for i in dd.index[(rel < 0.3) | (rel > 3.0)]: df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["yield_outlier_review"]
df["is_cultivated"] = df.total_area_clean > 0
df["dq_flags_str"] = df.dq_flags.apply(lambda f: ";".join(sorted(set(f))))
df["record_id"] = df.fiscal_year + "|" + df.district_raw.str.replace(r"\s+", "_", regex=True) + "|" + df.row_order.astype(str)

CLEAN = [f"{c}_clean" for c in cols]
MASTER_COLS = (["record_id", "source_table", "source_pdf_page", "sl_no", "fiscal_year", "year_start", "era", "district_raw", "district_std",
                "label_repaired", "label_repair_note", "row_type", "district_system", "division", "legacy_group_23", "has_variety_cols"] + RAW +
               ["chk_area_printed_minus_calc", "chk_prod_printed_minus_calc"] + CLEAN +
               ["yield_total_t_per_acre", "yield_local_t_per_acre", "yield_hyv_t_per_acre", "yield_indian_t_per_acre", "yield_total_kg_per_ha", "is_cultivated", "dq_flags_str"])
master = df[MASTER_COLS].copy()
for c in RAW + ["chk_area_printed_minus_calc", "chk_prod_printed_minus_calc"]: master[c] = master[c].astype("Int64")
for c in CLEAN: master[c] = master[c].round(0).astype("Int64")
master.to_csv(f"{OUT}/potato_master_long.csv", index=False)
aud.rename(columns={"table": "source_table", "pdf_page": "source_pdf_page", "name": "row_name_raw"}).to_csv(f"{OUT}/potato_raw_cells_audit.csv", index=False)

# ------------------------------------------------------------------ ML features
def features(d, ent, nat):
    d = d.sort_values(ent + ["year_start"]).reset_index(drop=True)
    d["variety_split_recorded"] = (d.year_start >= 1982).astype(int)
    for c in ("indian_area", "indian_prod"): d.loc[(d.year_start >= 1982) & (d.year_start < 2003) & d[c].isna() & d.local_area.notna(), c] = d[c]    # keep NaN
    ta = d.total_area.where(d.total_area > 0)
    d["local_area_share"] = d.local_area / ta; d["hyv_area_share"] = d.hyv_area / ta; d["indian_area_share"] = d.indian_area / ta
    d["yield_total_t_per_acre"] = np.where(d.total_area > 0, d.total_prod / d.total_area, np.nan)
    d["yield_local_t_per_acre"] = np.where(d.local_area > 0, d.local_prod / d.local_area, np.nan)
    d["yield_hyv_t_per_acre"] = np.where(d.hyv_area > 0, d.hyv_prod / d.hyv_area, np.nan)
    d["yield_indian_t_per_acre"] = np.where(d.indian_area > 0, d.indian_prod / d.indian_area, np.nan)
    d["yield_total_kg_per_ha"] = d.yield_total_t_per_acre * 1000 / ACRE_TO_HA
    d["area_ha"] = d.total_area * ACRE_TO_HA
    d = d.merge(nat, on="year_start", how="left")
    d["area_share_of_national"] = d.total_area / d.nat_total_area
    d["prod_share_of_national"] = d.total_prod / d.nat_total_prod
    d["yield_vs_national"] = d.yield_total_t_per_acre / d.nat_yield_total_t_per_acre
    d["_seg"] = (d.groupby(ent).year_start.diff().fillna(1) != 1).groupby([d[e] for e in ent]).cumsum()
    g = d.groupby(ent + ["_seg"], sort=False)
    for c in ["total_area", "total_prod", "yield_total_t_per_acre", "hyv_area_share"]:
        s = g[c]; d[f"{c}_lag1"] = s.shift(1); d[f"{c}_lag2"] = s.shift(2)
        d[f"{c}_roll3_prev_mean"] = s.transform(lambda x: x.shift(1).rolling(3, min_periods=1).mean())
    for c in ["total_area", "total_prod", "yield_total_t_per_acre"]:
        d[f"{c}_yoy_pct"] = np.where(d[f"{c}_lag1"] > 0, (d[c] / d[f"{c}_lag1"] - 1) * 100, np.nan)
    d["entity_hist_mean_yield"] = g["yield_total_t_per_acre"].transform(lambda x: x.shift(1).expanding().mean())
    d["t_index"] = d.year_start - d.year_start.min(); d["decade"] = (d.year_start // 10) * 10
    d["post_liberation"] = (d.year_start >= 1971).astype(int)
    d["target_total_prod_next_year"] = g["total_prod"].shift(-1)
    d["target_yield_next_year"] = g["yield_total_t_per_acre"].shift(-1)
    d["entity_id"] = d[ent].astype(str).agg("|".join, axis=1)
    return d.drop(columns="_seg")

nr = df[df.row_type == "national_total"].drop_duplicates("year_start")
nat = pd.DataFrame({"year_start": nr.year_start, "nat_total_area": nr.total_area_clean, "nat_total_prod": nr.total_prod_clean})
nat["nat_yield_total_t_per_acre"] = nat.nat_total_prod / nat.nat_total_area
ren = {f"{c}_clean": c for c in cols}
d0 = df[dist][["record_id", "fiscal_year", "year_start", "district_system", "district_std", "division", "legacy_group_23", "source_table",
               "label_repaired", "is_cultivated", "dq_flags_str"] + CLEAN].rename(columns=ren)
ml = features(d0, ["district_system", "district_std"], nat)
ML_COLS = ["record_id", "entity_id", "fiscal_year", "year_start", "t_index", "decade", "post_liberation", "district_system", "district_std",
           "division", "legacy_group_23", "source_table", "label_repaired", "variety_split_recorded",
           "local_area", "local_prod", "hyv_area", "hyv_prod", "indian_area", "indian_prod", "total_area", "area_ha", "total_prod",
           "local_area_share", "hyv_area_share", "indian_area_share",
           "yield_total_t_per_acre", "yield_local_t_per_acre", "yield_hyv_t_per_acre", "yield_indian_t_per_acre", "yield_total_kg_per_ha",
           "nat_total_area", "nat_total_prod", "nat_yield_total_t_per_acre", "area_share_of_national", "prod_share_of_national", "yield_vs_national",
           "total_area_lag1", "total_area_lag2", "total_area_roll3_prev_mean", "total_area_yoy_pct",
           "total_prod_lag1", "total_prod_lag2", "total_prod_roll3_prev_mean", "total_prod_yoy_pct",
           "yield_total_t_per_acre_lag1", "yield_total_t_per_acre_lag2", "yield_total_t_per_acre_roll3_prev_mean", "yield_total_t_per_acre_yoy_pct",
           "hyv_area_share_lag1", "hyv_area_share_lag2", "hyv_area_share_roll3_prev_mean", "entity_hist_mean_yield",
           "is_cultivated", "dq_flags_str", "target_total_prod_next_year", "target_yield_next_year"]
ml[ML_COLS].to_csv(f"{OUT}/potato_ml_ready_district_panel.csv", index=False)

# ------------------------------------------------------------------ harmonised panel 1979-80 .. 2014-15 (21 groups; hill tracts merged)
base = d0[d0.district_system != "20/21-district"].copy()
base["panel_group"] = base.legacy_group_23.where(~base.legacy_group_23.isin(HILL), "Chittagong Hill Tracts")
def smin(x): return x.sum(min_count=len(x)) if x.notna().all() else np.nan
vals = [c for c in cols]
agg = (base.groupby(["panel_group", "fiscal_year", "year_start"], as_index=False)
       .agg(**{c: (c, smin if not c.startswith("indian") else (lambda x: x.sum(min_count=1))) for c in vals}, n_components=("district_std", "nunique"), src_system=("district_system", "first"),
            flags=("dq_flags_str", lambda s: ";".join(sorted({f for x in s for f in str(x).split(";") if f and f != "nan"})))))
agg["district_std"] = agg.panel_group; agg["district_system"] = "21-group-harmonised"; agg["legacy_group_23"] = agg.panel_group
agg["division"] = agg.panel_group.map(lambda g: "Chittagong" if g == "Chittagong Hill Tracts" else G2DIV[g])
agg["is_aggregated_from_64"] = agg.src_system == "64-district"
agg["source_table"] = ""; agg["label_repaired"] = False; agg["record_id"] = "P21|" + agg.fiscal_year + "|" + agg.panel_group
agg["is_cultivated"] = agg.total_area > 0; agg["dq_flags_str"] = agg.flags
pan = features(agg, ["district_system", "district_std"], nat)
PCOLS = [c for c in ML_COLS if c in pan.columns] + ["n_components", "is_aggregated_from_64"]
pan[PCOLS].to_csv(f"{OUT}/potato_panel_21groups_1979_2015.csv", index=False)

# ------------------------------------------------------------------ report
print("rows master/ml/panel:", len(master), len(ml), len(pan))
print(master.dq_flags_str.str.split(";").explode().replace("", np.nan).dropna().value_counts().to_string())
nb = sum(sum(1 for v in json.loads(s) if v != "") for s in aud.raw_cells)
print("non-blank raw cells:", nb, "| printed values in master (per year-row):", int(master[RAW].notna().sum().sum()))
dsum = df[dist].groupby("fiscal_year")[["total_area_clean", "total_prod_clean"]].sum(min_count=1)
nn = df[df.row_type == "national_total"].set_index("fiscal_year")[["total_area_clean", "total_prod_clean"]]
gap = (dsum - nn); print("district sum (clean) minus national (clean), years with gap:"); print(gap[(gap.abs() > 2).any(axis=1)].to_string())
df.to_pickle("/tmp/potato_final.pkl"); rep_tbl.to_pickle("/tmp/potato_repairs.pkl")
