"""Parse 'Estimates of Boro rice' tables 1.3.1 - 1.3.46 (BBS, 45 years Agriculture Statistics)."""
import re, json
import pdfplumber
import numpy as np
import pandas as pd
from parse_amon import clean_cell, norm_name, HEAD, rows_of, sums_ok

PDF = "/mnt/user-data/uploads/45_years_of_Major_Crops__Boro_Rice_.pdf"
DIVNAME = {"01": "Chittagong Division", "02": "Sylhet Division", "03": "Dhaka Division", "04": "Barisal Division",
           "05": "Khulna Division", "06": "Rajshahi Division", "07": "Rangpur Division"}
YEAR_RE = re.compile(r"((?:19|20)\d\d)-(\d{4}|\d\d)")

def cats_for(y):
    if y <= 1975: return ["local", "hyv", "total"]
    if y <= 1997: return ["local", "hyv", "pajam", "total"]           # separate Pajam column 1976-77 .. 1997-98
    if y <= 2005: return ["local", "hyv", "total"]                    # 1998-99 .. 2005-06 (pajam inside HYV)
    return ["local", "hyv", "hybrid", "total"]                        # 2006-07 .. 2014-15

def fy_of(raw):
    m = YEAR_RE.search(raw); a, b = m.group(1), m.group(2)
    return f"{a}-{b[-2:]}"

def table_jobs(pdf):
    jobs, prev = [], None
    for pn, page in enumerate(pdf.pages, start=1):
        tabs = [(t, o) for t, o in zip(page.extract_tables(), page.find_tables()) if len(t) > 5]
        objs = [o for _, o in tabs]
        for k, (t, o) in enumerate(tabs):
            head = " ".join(" ".join(str(c) for c in r if c) for r in t[:4])
            m = YEAR_RE.search(head); tid = re.search(r"Table:\s*(1\s?\.3\.\d+)", head)
            raw = m.group(0) if m else None
            if raw is None or (prev and fy_of(raw) == prev["fy"]):        # no year in header, or same year again -> continuation page
                assert prev, (pn, head)
                job = dict(prev); job.update(page=pn, tab=t, obj=o, continuation=True)
            else:
                job = dict(page=pn, tab=t, obj=o, raw=raw, fy=fy_of(raw), table=(tid.group(1).replace(" ", "") if tid else "unlabelled"),
                           continuation=False)
            job["next_top"] = (objs[k + 1].bbox[1] - 2) if k + 1 < len(objs) else page.height
            jobs.append(job); prev = job
    return jobs

def text_rows(pdf, job, N):
    """rows read from the page text inside the table box: (name_text, last N numbers)"""
    o = job["obj"]; p = pdf.pages[job["page"] - 1]
    crop = p.crop((o.bbox[0] - 3, max(o.bbox[1] - 3, 0), o.bbox[2] + 3, job["next_top"]))
    out = []
    for line in (crop.extract_text() or "").split("\n"):
        toks = line.split(); nums = []
        while toks and re.fullmatch(r"\d+", toks[-1]): nums.append(toks.pop())
        nums = list(reversed(nums))
        if len(nums) >= N:
            pref = " ".join(toks); pref = re.sub(r"^\d+\s+", "", pref).strip()
            out.append((pref, nums[-N:]))
    return out

def main():
    pdf = pdfplumber.open(PDF)
    jobs = table_jobs(pdf)
    years = []
    for j in jobs:
        if not j["continuation"]: years.append(j["fy"])
    assert years == [f"{y}-{str(y + 1)[-2:]}" if y != 1999 else "1999-00" for y in range(1969, 2015)], years
    records, audit = [], []
    for J in jobs:
        y = int(J["fy"][:4]); cats = cats_for(y); ncat = len(cats); N = ncat * 2
        # patch garbled division labels (serial 01..07 with a numeric 'name')
        tab = []
        for r in J["tab"]:
            r = list(r)
            if r[0] and re.fullmatch(r"0[1-7]", str(r[0]).strip()) and r[1] is not None and not re.search(r"[A-Za-z]", str(r[1])):
                r[1] = DIVNAME[str(r[0]).strip()]; r.append("PATCHED")
            tab.append(r[:len(J["tab"][0])])
        patched = {DIVNAME[str(r[0]).strip()] for r in J["tab"] if r[0] and re.fullmatch(r"0[1-7]", str(r[0]).strip()) and r[1] is not None and not re.search(r"[A-Za-z]", str(r[1]))}
        trows = text_rows(pdf, J, N)
        grid_rows = list(rows_of(tab))
        seen = {re.sub(r"[^a-z]", "", n.lower()) for _, n, _ in grid_rows}
        extra = []
        for pref, nums in trows:                      # rows that sit outside the cell grid (glued to the page footer)
            k = re.sub(r"[^a-z]", "", pref.lower())
            if k and k not in seen and sums_ok(nums, ncat, 1):
                extra.append(("", pref, list(nums))); seen.add(k)
        for sl, name, vals in grid_rows + extra:
            is_extra = (sl, name, vals) in extra
            if not any(re.fullmatch(r"\d+", v) for v in vals): continue
            raw_vals = list(vals); flags = []
            if len(vals) != N:
                nb = [v for v in vals if v != ""]
                if len(nb) == N: vals = nb
                elif len(nb) == N + 1: vals = nb[:-2] + [nb[-2] + nb[-1]]; flags.append("last_col_cell_merged")
                else: raise ValueError(f"{J['table']} {J['fy']} {name}: expected {N} got {len(vals)} {raw_vals}")
            # cross-check against page text (grid sometimes spills digits / merges two numbers into one cell)
            if not sums_ok(vals, ncat, 1):
                key = re.sub(r"[^a-z]", "", name.lower())
                cands = [n for pref, n in trows if re.sub(r"[^a-z]", "", pref.lower()) == key]
                head = vals[:N - 2]
                cands += [n for pref, n in trows if n[:N - 2] == head and n != vals]
                good = [c for c in cands if sums_ok(c, ncat, 1)]
                if good and good[0] != vals:
                    vals = good[0]; flags.append("values_taken_from_page_text")
            if name in patched: flags.append("division_label_inferred_from_serial")
            if is_extra: flags.append("row_read_from_page_text")
            audit.append(dict(table=J["table"], fy=J["fy"], pdf_page=J["page"], sl=sl, name=name, raw_cells=json.dumps(raw_vals)))
            rtype = ("national_total" if name.lower().startswith("bangladesh")
                     else "division_subtotal" if "division" in name.lower() or name.lower().startswith("khunna") else "district")
            rec = dict(source_table=J["table"], source_pdf_page=J["page"], fy_label_raw=J["raw"], fiscal_year=J["fy"],
                       district_raw=name, row_type=rtype, sl_no=sl.replace("\n", "/"), cats=",".join(cats), dq_flags=list(flags))
            for c, cat in enumerate(cats):
                for k, m in enumerate(["area", "prod"]):
                    v = vals[c * 2 + k]; rec[f"{cat}_{m}"] = int(v) if v != "" else np.nan
            if any(v == "" for v in vals): rec["dq_flags"].append("blank_cell_in_source")
            records.append(rec)
    return pd.DataFrame(records), pd.DataFrame(audit)

if __name__ == "__main__":
    df, aud = main()
    df.to_pickle("/tmp/boro_raw.pkl"); aud.to_pickle("/tmp/boro_audit.pkl")
    print(df.shape, aud.shape)
    print(df.groupby(["fiscal_year", "row_type"]).size().unstack(fill_value=0).to_string())
    print(df.dq_flags.explode().value_counts())
