"""Parse 'Estimates of Amon (Aman) rice' tables 1.2.1 - 1.2.41 (BBS, 45 years Agriculture Statistics)."""
import re, json
import pdfplumber
import numpy as np
import pandas as pd

PDF = "/mnt/user-data/uploads/45_years_of_Major_Crops__Amon_rice_.pdf"
C4 = ["bcast", "ltrans", "hyv", "total"]                 # pajam is inside HYV (<=1976-77, >=1999-00)
C5 = ["bcast", "ltrans", "hyv", "pajam", "total"]        # separate Pajam column 1977-78 .. 1998-99

def fy_of(raw):
    return "1999-00" if raw == "1999-2000" else raw

# (pdf page, table index on page, table id, printed year label, categories, district system)
LAYOUT = []
def add(page, idx, tid, raw, cats, system):
    LAYOUT.append(dict(page=page, idx=idx, table=tid, raw=raw, fy=fy_of(raw), cats=cats, system=system))

# pages 1-3: two years side by side in one table (handled with years list)
MULTI = {  # page -> (table id, [raw years], cats, system)
    1: ("1.2.1", ["1969-70", "1970-71"], C4, "20-district"),
    2: ("1.2.2", ["1971-72", "1972-73"], C4, "20-district"),
    3: ("1.2.3", ["1973-74", "1974-75"], C4, "20-district"),
}
add(4, 0, "unnumbered_p4a", "1975-76", C4, "20-district")
add(4, 1, "unnumbered_p4b", "1976-77", C4, "21-district")
add(5, 0, "1.2.4", "1977-78", C5, "21-district")
add(5, 1, "1.2.5", "1978-79", C5, "21-district")
yrs = ["1979-80","1980-81","1981-82","1982-83","1983-84","1984-85","1985-86","1986-87","1987-88","1988-89",
       "1989-90","1990-91","1991-92","1992-93","1993-94","1994-95","1995-96","1996-97","1997-98","1998-99"]
tno = 6                                    # tables 1.2.6 .. 1.2.25
page, idx = 6, 0
for y in yrs:
    if y == "1993-94":                     # page 13 holds a single table
        add(13, 0, f"1.2.{tno}", y, C5, "23-district"); tno += 1; page, idx = 14, 0; continue
    add(page, idx, f"1.2.{tno}", y, C5, "23-district"); tno += 1
    idx += 1
    if idx == 2: page, idx = page + 1, 0
# page 16 holds 1.2.25 (1998-99) then 1.2.26 (1999-2000)
add(16, 1, "1.2.26", "1999-2000", C4, "23-district")
y2 = [("1.2.27","2000-01",17,0),("1.2.28","2001-02",17,1),("1.2.29","2002-03",18,0),("1.2.30","2003-04",18,1),
      ("1.2.31","2004-05",19,0),("1.2.32","2005-06",19,1)]
for t, y, p, i in y2: add(p, i, t, y, C4, "23-district")
for t, y, p in [("1.2.33","2006-07",20),("1.2.34","2007-08",21),("1.2.35","2008-09",22),("1.2.36","2009-10",23),
                ("1.2.37","2010-11",24),("1.2.38","2011-12",25),("1.2.39","2012-13",26),("1.2.40","2013-14",27),
                ("1.2.41","2014-15",28)]:
    add(p, 0, t, y, C4, "64-district")

HEAD = re.compile(r"^(Table|Sl|Estimates|Zila|Local|HYV|Total|Pajam|Area|Name|Districts|Broadcast|Production)", re.I)
def clean_cell(c): return "" if c is None else re.sub(r"\s+", "", str(c))

def norm_name(n):
    n = re.sub(r"\s+", " ", n).strip()
    n = re.sub(r"^\d+\s+(?=\D)", "", n)            # leading serial glued into the name
    n = n.replace("Mymensing h", "Mymensingh")
    return n

def rows_of(table):
    for row in table:
        cells = ["" if c is None else str(c).strip() for c in row]
        if not any(cells) or cells[0].startswith(("Table", "Estimates")):
            continue
        name = idx = None
        for i, c in enumerate(cells[:3]):
            flat = re.sub(r"\s+", " ", c)
            if re.search(r"[A-Za-z]{3}", flat) and not HEAD.match(flat):
                name, idx = norm_name(flat), i; break
        if name is None: continue
        vals = [clean_cell(c) for c in cells[idx + 1:]]
        if idx == 0:
            while vals and vals[0] == "": vals = vals[1:]
        yield cells[0] if idx else "", name, vals


def text_lines(pdf, J, tab_obj, next_top):
    p = pdf.pages[J["page"] - 1]
    crop = p.crop((tab_obj.bbox[0] - 3, max(tab_obj.bbox[1] - 3, 0), tab_obj.bbox[2] + 3, next_top))
    out = []
    for line in (crop.extract_text() or "").split("\n"):
        toks = line.split()
        nums = []
        for t in reversed(toks):
            if re.fullmatch(r"\d+", t): nums.append(t)
            else: break
        out.append(list(reversed(nums)))
    return out

def sums_ok(vals, ncat, nyear):
    """Total = sum of the other categories (area and production), tolerance +-1 for source rounding"""
    try:
        v = [int(x) if x != "" else None for x in vals]
    except ValueError:
        return False
    if any(x is None for x in v): return False
    for y in range(nyear):
        b = v[y * ncat * 2:(y + 1) * ncat * 2]
        for k in (0, 1):
            parts = sum(b[c * 2 + k] for c in range(ncat - 1)); tot = b[(ncat - 1) * 2 + k]
            if abs(parts - tot) > 1: return False
    return True

def main():
    pdf = pdfplumber.open(PDF)
    records, audit = [], []
    jobs = []
    for pg, (t, ys, cats, sysm) in MULTI.items():
        jobs.append(dict(page=pg, idx=0, table=t, raws=ys, cats=cats, system=sysm))
    for L in LAYOUT:
        jobs.append(dict(page=L["page"], idx=L["idx"], table=L["table"], raws=[L["raw"]], cats=L["cats"], system=L["system"]))
    for J in jobs:
        page_obj = pdf.pages[J["page"] - 1]
        tab = page_obj.extract_tables()[J["idx"]]
        tobjs = [t for t in page_obj.find_tables() if (t.bbox[3] - t.bbox[1]) > 100]       # drop the page-number box
        tobj = tobjs[J["idx"]]
        next_top = tobjs[J["idx"] + 1].bbox[1] - 2 if J["idx"] + 1 < len(tobjs) else page_obj.height - 40
        head = " ".join(" ".join(str(c) for c in r if c) for r in tab[:3])
        for r in J["raws"]:
            assert r in head, (J["table"], r, head[:200])          # header year matches the layout I hard-coded
        ncat, nyear = len(J["cats"]), len(J["raws"]); N = nyear * ncat * 2
        rows = list(rows_of(tab))
        tl = text_lines(pdf, J, tobj, next_top)
        natflag = False
        if not any(n.lower().startswith("bangladesh") for _, n, _ in rows):      # national row sits outside the grid
            crop_txt = page_obj.crop((tobj.bbox[0] - 3, max(tobj.bbox[1] - 3, 0), tobj.bbox[2] + 3, next_top)).extract_text().split("\n")
            line = [l for l in crop_txt if l.startswith("Bangladesh")][0]
            nums = re.findall(r"\d+", line.split("Bangladesh", 1)[1])
            assert len(nums) == N, (J["table"], line)
            rows.append(("", "Bangladesh", nums)); natflag = True
        for sl, name, vals in rows:
            if not any(re.fullmatch(r"\d+", v) for v in vals): continue
            raw_vals = list(vals); flags = ["national_row_read_from_page_text"] if (natflag and name == "Bangladesh") else []
            if len(vals) != N:
                nb = [v for v in vals if v != ""]
                if len(nb) == N: vals = nb
                elif len(nb) == N + 1: vals = nb[:-2] + [nb[-2] + nb[-1]]; flags.append("last_col_cell_merged")
                else: raise ValueError(f"{J['table']} {name}: expected {N} got {len(vals)} {raw_vals}")
            # cross-check with the page text: the cell grid sometimes spills a digit into the neighbouring cell
            if not natflag or name != "Bangladesh":
                head = [v for v in vals[:N - 2]]
                cands = [t[-N:] for t in tl if len(t) >= N and t[-N:][:N - 2] == head]
                cands = [c for c in cands if c != vals]
                if cands and (not sums_ok(vals, ncat, nyear)) and sums_ok(cands[0], ncat, nyear):
                    vals = cands[0]; flags.append("values_taken_from_page_text")
            audit.append(dict(table=J["table"], pdf_page=J["page"], sl=sl, name=name, raw_cells=json.dumps(raw_vals)))
            rtype = ("national_total" if name.lower().startswith("bangladesh")
                     else "division_subtotal" if "Division" in name else "district")
            for y, raw in enumerate(J["raws"]):
                rec = dict(source_table=J["table"], source_pdf_page=J["page"], fy_label_raw=raw, fiscal_year=fy_of(raw),
                           district_raw=name, row_type=rtype, district_system=J["system"], sl_no=sl.replace("\n", "/"),
                           has_pajam_col=("pajam" in J["cats"]))
                fl = list(flags)
                for c, cat in enumerate(J["cats"]):
                    for k, m in enumerate(["area", "prod"]):
                        v = vals[y * ncat * 2 + c * 2 + k]
                        rec[f"{cat}_{m}"] = int(v) if v != "" else np.nan
                if any(v == "" for v in vals[y * ncat * 2:(y + 1) * ncat * 2]): fl.append("blank_cell_in_source")
                rec["dq_flags"] = fl
                records.append(rec)
    return pd.DataFrame(records), pd.DataFrame(audit)

if __name__ == "__main__":
    df, aud = main()
    df.to_pickle("/tmp/amon_raw.pkl"); aud.to_pickle("/tmp/amon_audit.pkl")
    print(df.shape, aud.shape)
    g = df.groupby(["fiscal_year", "row_type"]).size().unstack(fill_value=0)
    print(g.to_string())
