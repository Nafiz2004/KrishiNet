import json, os, re
import numpy as np, pandas as pd
from parse_amon import main as parse_pdf

OUT = "/mnt/user-data/outputs"
os.makedirs(OUT, exist_ok=True)
ACRE_TO_HA = 0.40468564224
COMPS = ["bcast", "ltrans", "hyv", "pajam"]
RAW = [f"{c}_{m}" for c in COMPS for m in ("area", "prod")] + ["total_area", "total_prod"]

df, aud = parse_pdf()
for c in ["pajam_area", "pajam_prod"]:
    if c not in df: df[c] = np.nan
df = df.reset_index(drop=True)
df["dq_flags"] = df.dq_flags.apply(list)
def flag(mask, text):
    for i in df.index[mask]: df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [text]

# ------------------------------------------------------------------ names / year / system
STD = {"Bakergonj": "Barisal", "Khustia": "Kushtia", "Mymenshing": "Mymensingh", "Kishoregonj": "Kishoreganj",
       "Sunamgonj": "Sunamganj", "Hobigonj": "Habiganj", "Maulavibazar": "Moulvibazar", "Manikgonj": "Manikganj",
       "Munshigonj": "Munshiganj", "Munsigonj": "Munshiganj", "Narayangonj": "Narayanganj", "Gopalgonj": "Gopalganj",
       "Perojpur": "Pirojpur", "Noagaon": "Naogaon", "Nawabgonj": "Nawabganj", "Sirajgonj": "Sirajganj",
       "Jhalakathi": "Jhalokati", "BANGLADESH": "Bangladesh"}
def std_name(n):
    k = re.sub(r"[\s\.]", "", n).lower()
    if k == "chittagongh t".replace(" ", "") or k == "chittagongh t" or k == "chittagonght": return "Chittagong Hill Tracts"
    return STD.get(n, n)
df["district_std"] = df.district_raw.map(std_name)
df["year_start"] = df.fiscal_year.str[:4].astype(int)
df["year_label_corrected"] = False                      # all Amon year labels are printed correctly (1999-2000 -> 1999-00 is only a format change)
df["district_system"] = np.where(df.year_start < 1979, "20/21-district", df.district_system)
df["unit_production_label"] = np.where(df.year_start < 2006, "tons", "M.tons")

# ------------------------------------------------------------------ label scrambles in the PDF (2013-14, 2014-15)
# 2014-15: printed labels in the Rajshahi/Rangpur block are shifted by one row. Verified exactly: with the relabelling,
#          Rajshahi-division and Rangpur-division totals equal the sum of their districts and districts add up to the national total area.
FIX_1415 = {"Panchagar": "Pabna", "Pabna": "Sirajganj", "Sirajganj": "Rajshahi", "Rajshahi": "Naogaon", "Naogaon": "Natore",
            "Natore": "Nawabganj", "Nawabganj": "@Rajshahi Division", "Rajshahi Division": "Dinajpur", "Dinajpur": "Thakurgaon",
            "Thakurgaon": "Panchagar"}
# 2013-14: rows rotated/permuted in the Barisal+Khulna and Rajshahi+Rangpur blocks. Inferred by similarity to 2012-13 and 2014-15
#          (area, variety mix); block structure is a clean rotation, rows with weaker evidence are flagged 'medium'.
FIX_1314 = {"Patuakhali": "Chuadanga", "Barguna": "Meherpur", "Jessore": "Patuakhali", "Jhenaidah": "Barguna", "Magura": "Jessore",
            "Narail": "Jhenaidah", "Khulna": "Magura", "Bagerhat": "Narail", "Satkhira": "Khulna", "Kushtia": "Bagerhat",
            "Chuadanga": "Satkhira", "Meherpur": "Kushtia",
            "Panchagar": "Rajshahi", "Pabna": "Naogaon", "Sirajganj": "Natore", "Rajshahi": "Nawabganj", "Naogaon": "Dinajpur",
            "Natore": "Thakurgaon", "Nawabganj": "Panchagar", "Dinajpur": "Pabna", "Thakurgaon": "Sirajganj"}
MEDIUM_1314 = {"Rajshahi", "Natore", "Sirajganj", "Pabna"}      # true districts whose assignment rests on variety mix more than size
df["label_repaired"] = False; df["label_repair_note"] = ""
for fy, fix, note in [("2014-15", FIX_1415, "label_repaired_2014_15_verified_by_sums"), ("2013-14", FIX_1314, "label_repaired_2013_14_inferred")]:
    idxs = df.index[(df.fiscal_year == fy) & (df.row_type != "national_total")]
    old = {i: df.at[i, "district_std"] for i in idxs}
    for i in idxs:
        o = old[i]
        if o in fix:
            new = fix[o]
            if new.startswith("@"):
                df.at[i, "district_std"] = new[1:]; df.at[i, "row_type"] = "division_subtotal"
            else:
                df.at[i, "district_std"] = new
                if df.at[i, "row_type"] == "division_subtotal": df.at[i, "row_type"] = "district"
            df.at[i, "label_repaired"] = True
            tag = note + ("_medium_confidence" if (fy == "2013-14" and new in MEDIUM_1314) else "")
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [tag]
            df.at[i, "label_repair_note"] = f"printed '{df.at[i, 'district_raw']}' -> '{df.at[i, 'district_std']}'"
# 2013-14 printed division subtotals were summed over the scrambled membership
flag((df.fiscal_year == "2013-14") & (df.row_type == "division_subtotal") &
     df.district_std.str.contains("Barisal|Khulna|Rajshahi|Rangpur"), "src_division_total_built_on_scrambled_rows")

# ------------------------------------------------------------------ geography (division scheme from the PDF's own 2012-13 table)
G23 = {
 "Bandarban": ["Bandarban"], "Chittagong": ["Chittagong", "Cox's Bazar"], "Comilla": ["Comilla", "Chandpur", "Brahmanbaria"],
 "Khagrachari": ["Khagrachari"], "Noakhali": ["Noakhali", "Lakshmipur", "Feni"], "Rangamati": ["Rangamati"],
 "Sylhet": ["Sylhet", "Moulvibazar", "Sunamganj", "Habiganj"],
 "Dhaka": ["Dhaka", "Gazipur", "Manikganj", "Munshiganj", "Narayanganj", "Narsingdi"],
 "Faridpur": ["Faridpur", "Rajbari", "Madaripur", "Gopalganj", "Shariatpur"], "Jamalpur": ["Jamalpur", "Sherpur"],
 "Kishoreganj": ["Kishoreganj", "Netrokona"], "Mymensingh": ["Mymensingh"], "Tangail": ["Tangail"],
 "Barisal": ["Barisal", "Jhalokati", "Pirojpur", "Bhola"], "Jessore": ["Jessore", "Jhenaidah", "Magura", "Narail"],
 "Khulna": ["Khulna", "Bagerhat", "Satkhira"], "Kushtia": ["Kushtia", "Chuadanga", "Meherpur"],
 "Patuakhali": ["Patuakhali", "Barguna"], "Bogra": ["Bogra", "Joypurhat"], "Dinajpur": ["Dinajpur", "Thakurgaon", "Panchagar"],
 "Pabna": ["Pabna", "Sirajganj"], "Rajshahi": ["Rajshahi", "Naogaon", "Natore", "Nawabganj"],
 "Rangpur": ["Rangpur", "Gaibandha", "Kurigram", "Nilphamari", "Lalmonirhat"]}
D2G = {d: g for g, ds in G23.items() for d in ds}; assert len(D2G) == 64
HILL = {"Bandarban", "Khagrachari", "Rangamati"}
t = df[df.fiscal_year == "2012-13"].reset_index(drop=True)
div, pend = {}, []
for _, r in t.iterrows():
    if r.row_type == "district": pend.append(r.district_std)
    elif r.row_type == "division_subtotal":
        for d in pend: div[d] = r.district_std.replace(" Division", "")
        pend = []
assert len(div) == 64, len(div)
G2DIV = {}
for g, ds in G23.items():
    s = {div[d] for d in ds}; assert len(s) == 1, (g, s); G2DIV[g] = s.pop()
OLD_DIV = {"Chittagong Hill Tracts": "Chittagong"}
def division_of(r):
    if r.row_type != "district": return np.nan
    if r.district_system == "64-district": return div[r.district_std]
    return G2DIV.get(r.district_std, OLD_DIV.get(r.district_std, np.nan))
def group_of(r):
    if r.row_type != "district": return np.nan
    return D2G[r.district_std] if r.district_system == "64-district" else r.district_std
df["division"] = df.apply(division_of, axis=1)
df["legacy_group_23"] = df.apply(group_of, axis=1)

# ------------------------------------------------------------------ clean component columns
for c in RAW:
    if c.startswith("total"): continue
    df[f"{c}_clean"] = df[c].astype(float)
dist_mask = df.row_type == "district"

# R1. 2010-11: broadcast production column is shifted up by one row from Jhalakathi (serial 34) to the end of the table.
m = (df.fiscal_year == "2010-11") & dist_mask
rows = list(df.index[m]); assert len(rows) == 64
printed = df.loc[rows, "bcast_prod"].tolist()
start = 33                                                     # zero-based position of serial 34 (Jhalakathi)
new = printed[:]
for k in range(start + 1, 64): new[k] = printed[k - 1]
new[start] = 0.0 if df.at[rows[start], "bcast_area"] == 0 else np.nan
df.loc[rows, "bcast_prod_clean"] = new
yb = pd.Series(new, index=rows) / df.loc[rows, "bcast_area"].where(df.loc[rows, "bcast_area"] > 1000)
assert yb.dropna().between(0.2, 0.9).all(), yb.describe()      # after the shift every broadcast yield is plausible
for i in rows[start:]: df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["adj_2010_11_bcast_prod_shifted_down_one_row"]

# R2. single-digit slips (a digit dropped/inserted in an area or production cell)
BAND = {"bcast": (0.12, 1.0), "ltrans": (0.12, 1.15), "hyv": (0.25, 2.0)}
def neigh_vals(i, comp, which):
    r = df.loc[i]; res = []
    for dy in (-1, 1):
        j = df.index[(df.district_std == r.district_std) & (df.year_start == r.year_start + dy) & (df.row_type == "district")]
        if len(j):
            v = df.at[j[0], f"{comp}_{which}_clean"]
            if pd.notna(v) and v > 0: res.append(v)
    return res
def mindist(val, nbs):
    return min(abs(np.log(val / n)) for n in nbs) if nbs and val > 0 else np.inf
repairs = []
for comp, (lo, hi) in BAND.items():
    a, p = f"{comp}_area_clean", f"{comp}_prod_clean"
    y = df[p] / df[a].where(df[a] > 0)
    bad = df.index[dist_mask & (df[a] >= 1000) & ((y < lo) | (y > hi))]
    for i in bad:
        A, P = df.at[i, a], df.at[i, p]
        nA, nP = neigh_vals(i, comp, "area"), neigh_vals(i, comp, "prod")
        dA, dP = mindist(A, nA), mindist(P, nP)
        which = "area" if dA > dP else "prod"                  # the cell that disagrees with the neighbouring years is the faulty one
        cands = []
        for lab, na, np_ in ([("area_x10", A * 10, P), ("area_div10", A / 10, P)] if which == "area" else [("prod_x10", A, P * 10), ("prod_div10", A, P / 10)]):
            if na != int(na) or np_ != int(np_): continue
            if not (lo <= np_ / na <= hi): continue
            val, nbs = (na, nA) if which == "area" else (np_, nP)
            cands.append((mindist(val, nbs), lab, na, np_))
        cands.sort()
        if cands and cands[0][0] < np.log(1.6):
            _, lab, na, np_ = cands[0]
            df.at[i, a], df.at[i, p] = na, np_
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"adj_{comp}_{lab}"]
            repairs.append((df.at[i, "fiscal_year"], df.at[i, "district_std"], comp, lab, A, P, na, np_))
        else:
            df.at[i, a] = np.nan; df.at[i, p] = np.nan
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"suspect_unrecoverable_{comp}_nulled"]
            repairs.append((df.at[i, "fiscal_year"], df.at[i, "district_std"], comp, "NULLED", A, P, np.nan, np.nan))
rep_tbl = pd.DataFrame(repairs, columns=["fy", "district", "component", "action", "area_raw", "prod_raw", "area_clean", "prod_clean"])
print(rep_tbl.to_string())

# totals = sum of components (the PDF totals equal this everywhere except the cases flagged below)
def comp_sum(d, which):
    parts = [d[f"{c}_{which}_clean"] for c in ["bcast", "ltrans", "hyv"]] + [d[f"pajam_{which}_clean"].fillna(0)]
    s = sum(p.fillna(0) for p in parts)
    anynan = d[[f"{c}_{which}_clean" for c in ["bcast", "ltrans", "hyv"]]].isna().any(axis=1)
    return s.where(~anynan)
for w in ("area", "prod"):
    df[f"total_{w}_clean"] = comp_sum(df, w)
# printed totals vs sum of printed components
z = lambda c: df[c].fillna(0)
df["total_area_calc_printed"] = z("bcast_area") + z("ltrans_area") + z("hyv_area") + z("pajam_area")
df["total_prod_calc_printed"] = z("bcast_prod") + z("ltrans_prod") + z("hyv_prod") + z("pajam_prod")
df["chk_area_printed_minus_calc"] = df.total_area - df.total_area_calc_printed
df["chk_prod_printed_minus_calc"] = df.total_prod - df.total_prod_calc_printed
flag((df.row_type == "district") & df.total_area.isna() & df.total_prod.notna(), "blank_total_area_filled_from_components")
flag((df.chk_area_printed_minus_calc.abs() > 1) | (df.chk_prod_printed_minus_calc.abs() > 1), "src_printed_total_not_equal_sum_of_parts")
flag((df.chk_area_printed_minus_calc.abs() == 1) | (df.chk_prod_printed_minus_calc.abs() == 1), "src_rounding_diff_1")

# ------------------------------------------------------------------ national / division clean values
FILL = {}
for c in RAW:
    if c.startswith("total"): continue
    base = df[f"{c}_clean"].where(df[f"{c}_clean"].notna(), df[c])      # unrecoverable cells keep their printed value inside aggregates
    FILL[c] = base
d_ok = df.row_type == "district"
natmask = df.row_type == "national_total"
for fy in df.fiscal_year.unique():
    sel = d_ok & (df.fiscal_year == fy)
    ni = df.index[natmask & (df.fiscal_year == fy)]
    assert len(ni) == 1
    for c in RAW:
        if c.startswith("total"): continue
        df.at[ni[0], f"{c}_clean"] = FILL[c][sel].sum()
    for w in ("area", "prod"):
        df.at[ni[0], f"total_{w}_clean"] = sum(df.at[ni[0], f"{c}_{w}_clean"] for c in ["bcast", "ltrans", "hyv"]) + (df.at[ni[0], f"pajam_{w}_clean"] if pd.notna(df.at[ni[0], f"pajam_{w}_clean"]) else 0)
for fy in ["2012-13", "2013-14", "2014-15"]:
    for i in df.index[(df.fiscal_year == fy) & (df.row_type == "division_subtotal")]:
        dn = df.at[i, "district_std"].replace(" Division", "")
        sel = d_ok & (df.fiscal_year == fy) & (df.division == dn)
        for c in RAW:
            if c.startswith("total"): continue
            df.at[i, f"{c}_clean"] = FILL[c][sel].sum()
        for w in ("area", "prod"):
            df.at[i, f"total_{w}_clean"] = sum(df.at[i, f"{c}_{w}_clean"] for c in ["bcast", "ltrans", "hyv"])
        if abs(df.at[i, "total_area_clean"] - df.at[i, "total_area"]) > 1 or abs(df.at[i, "total_prod_clean"] - df.at[i, "total_prod"]) > 1:
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["division_total_recomputed_differs_from_printed"]
# national printed vs clean
chk = df[natmask].copy()
for c in RAW:
    base = c if c.startswith("total") else c
    clean_col = f"{c}_clean"
    d = (chk[c] - chk[clean_col]).abs()
    for i in chk.index[d > 1]:
        df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"src_national_printed_{c}_differs_from_district_sum"]

# ------------------------------------------------------------------ structural notes
flag((df.row_type == "district") & (df.district_std == "Rangamati") & df.fiscal_year.isin(["1979-80", "1980-81", "1981-82", "1982-83", "1983-84"]),
     "src_note_cht_figures_shown_against_rangamati")
flag((df.row_type == "district") & df.district_std.isin(["Bandarban", "Khagrachari"]) & df.fiscal_year.isin(["1979-80", "1980-81", "1981-82", "1982-83", "1983-84"]) & (df.total_area_clean == 0),
     "structural_zero_cht_counted_under_rangamati")
flag((df.row_type == "district") & (df.year_start <= 1978) & (df.total_area_clean == 0), "structural_zero_not_yet_separate_district")
flag(df.dq_flags.apply(lambda f: "last_col_cell_merged" in f), "note_cell_fragments_rejoined")

# ------------------------------------------------------------------ yields (clean)
def add_yields(d, sfx="_clean"):
    pa = lambda p, a: np.where(d[a] > 0, d[p] / d[a], np.nan)
    d["yield_total_t_per_acre"] = pa(f"total_prod{sfx}", f"total_area{sfx}")
    d["yield_bcast_t_per_acre"] = pa(f"bcast_prod{sfx}", f"bcast_area{sfx}")
    d["yield_ltrans_t_per_acre"] = pa(f"ltrans_prod{sfx}", f"ltrans_area{sfx}")
    ha = d[f"hyv_area{sfx}"] + d[f"pajam_area{sfx}"].fillna(0); hp = d[f"hyv_prod{sfx}"] + d[f"pajam_prod{sfx}"].fillna(0)
    d["yield_hyv_incl_pajam_t_per_acre"] = np.where(ha > 0, hp / ha, np.nan)
    d["yield_total_kg_per_ha"] = d.yield_total_t_per_acre * 1000 / ACRE_TO_HA
    return d
df = add_yields(df)
dd = df[(df.row_type == "district") & (df.total_area_clean >= 1000)]
for i in dd.index[(dd.yield_total_t_per_acre < 0.15) | (dd.yield_total_t_per_acre > 1.6)]:
    df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["yield_outlier_review"]

df["is_cultivated"] = df.total_area_clean > 0
df["dq_flags_str"] = df.dq_flags.apply(lambda f: ";".join(sorted(set(f))))
df["record_id"] = df.source_table + "|" + df.fiscal_year + "|" + df.district_raw.str.replace(r"\s+", "_", regex=True)

PRINTED = [f"{c}_{m}" for c in COMPS for m in ("area", "prod")] + ["total_area", "total_prod"]
CLEAN = [f"{c}_{m}_clean" for c in COMPS for m in ("area", "prod")] + ["total_area_clean", "total_prod_clean"]
MASTER_COLS = (["record_id", "source_table", "source_pdf_page", "sl_no", "fy_label_raw", "fiscal_year", "year_start",
                "district_raw", "district_std", "label_repaired", "label_repair_note", "row_type", "district_system", "division",
                "legacy_group_23", "has_pajam_col", "unit_production_label"] + PRINTED +
               ["chk_area_printed_minus_calc", "chk_prod_printed_minus_calc"] + CLEAN +
               ["yield_total_t_per_acre", "yield_bcast_t_per_acre", "yield_ltrans_t_per_acre", "yield_hyv_incl_pajam_t_per_acre",
                "yield_total_kg_per_ha", "is_cultivated", "dq_flags_str"])
master = df[MASTER_COLS].copy()
for c in PRINTED + ["chk_area_printed_minus_calc", "chk_prod_printed_minus_calc"]:
    master[c] = master[c].astype("Int64")
for c in CLEAN:
    master[c] = master[c].round(0).astype("Int64")
master.to_csv(f"{OUT}/amon_rice_master_long.csv", index=False)
aud.rename(columns={"table": "source_table", "pdf_page": "source_pdf_page", "name": "row_name_raw"}).to_csv(f"{OUT}/amon_rice_raw_cells_audit.csv", index=False)

# ------------------------------------------------------------------ ML features
def features(d, ent, nat):
    d = d.sort_values(ent + ["year_start"]).reset_index(drop=True)
    d["local_area"] = d.bcast_area + d.ltrans_area
    d["local_prod"] = d.bcast_prod + d.ltrans_prod
    d["hyv_incl_pajam_area"] = d.hyv_area + d.pajam_area.fillna(0)
    d["hyv_incl_pajam_prod"] = d.hyv_prod + d.pajam_prod.fillna(0)
    ta = d.total_area.where(d.total_area > 0)
    d["bcast_area_share"] = d.bcast_area / ta; d["ltrans_area_share"] = d.ltrans_area / ta; d["hyv_area_share"] = d.hyv_incl_pajam_area / ta
    d["yield_total_t_per_acre"] = np.where(d.total_area > 0, d.total_prod / d.total_area, np.nan)
    d["yield_bcast_t_per_acre"] = np.where(d.bcast_area > 0, d.bcast_prod / d.bcast_area, np.nan)
    d["yield_ltrans_t_per_acre"] = np.where(d.ltrans_area > 0, d.ltrans_prod / d.ltrans_area, np.nan)
    d["yield_hyv_t_per_acre"] = np.where(d.hyv_incl_pajam_area > 0, d.hyv_incl_pajam_prod / d.hyv_incl_pajam_area, np.nan)
    d["yield_total_kg_per_ha"] = d.yield_total_t_per_acre * 1000 / ACRE_TO_HA
    d["area_ha"] = d.total_area * ACRE_TO_HA
    d = d.merge(nat, on="year_start", how="left")
    d["area_share_of_national"] = d.total_area / d.nat_total_area
    d["prod_share_of_national"] = d.total_prod / d.nat_total_prod
    d["yield_vs_national"] = d.yield_total_t_per_acre / d.nat_yield_total_t_per_acre
    g = d.groupby(ent, sort=False)
    assert (g.year_start.diff().dropna() == 1).all()
    for c in ["total_area", "total_prod", "yield_total_t_per_acre", "hyv_area_share"]:
        s = g[c]; d[f"{c}_lag1"] = s.shift(1); d[f"{c}_lag2"] = s.shift(2)
        d[f"{c}_roll3_prev_mean"] = s.transform(lambda x: x.shift(1).rolling(3, min_periods=1).mean())
    for c in ["total_area", "total_prod", "yield_total_t_per_acre"]:
        d[f"{c}_yoy_pct"] = np.where(d[f"{c}_lag1"] > 0, (d[c] / d[f"{c}_lag1"] - 1) * 100, np.nan)
    d["entity_hist_mean_yield"] = g["yield_total_t_per_acre"].transform(lambda x: x.shift(1).expanding().mean())
    d["t_index"] = d.year_start - d.year_start.min()
    d["decade"] = (d.year_start // 10) * 10
    d["post_liberation"] = (d.year_start >= 1971).astype(int)
    d["target_total_prod_next_year"] = g["total_prod"].shift(-1)
    d["target_yield_next_year"] = g["yield_total_t_per_acre"].shift(-1)
    d["entity_id"] = d[ent].astype(str).agg("|".join, axis=1)
    return d

nr = df[natmask].drop_duplicates("year_start")
nat = pd.DataFrame({"year_start": nr.year_start, "nat_total_area": nr.total_area_clean, "nat_total_prod": nr.total_prod_clean,
                    "nat_hyv_share_area": (nr.hyv_area_clean + nr.pajam_area_clean.fillna(0)) / nr.total_area_clean,
                    "nat_bcast_share_area": nr.bcast_area_clean / nr.total_area_clean})
nat["nat_yield_total_t_per_acre"] = nat.nat_total_prod / nat.nat_total_area

def rename_clean(d):
    return d.rename(columns={f"{c}_clean": c for c in [f"{k}_{m}" for k in COMPS for m in ("area", "prod")] + ["total_area", "total_prod"]})
dist = rename_clean(df[df.row_type == "district"][["record_id", "fiscal_year", "year_start", "district_system", "district_std", "division",
                                                    "legacy_group_23", "source_table", "label_repaired", "is_cultivated", "dq_flags_str"] +
                                                   CLEAN].copy())
dist["pajam_area"] = dist.pajam_area.fillna(0); dist["pajam_prod"] = dist.pajam_prod.fillna(0)
ml = features(dist, ["district_system", "district_std"], nat)
ML_COLS = ["record_id", "entity_id", "fiscal_year", "year_start", "t_index", "decade", "post_liberation", "district_system",
           "district_std", "division", "legacy_group_23", "source_table", "label_repaired",
           "bcast_area", "bcast_prod", "ltrans_area", "ltrans_prod", "local_area", "local_prod", "hyv_area", "hyv_prod",
           "pajam_area", "pajam_prod", "hyv_incl_pajam_area", "hyv_incl_pajam_prod", "total_area", "area_ha", "total_prod",
           "bcast_area_share", "ltrans_area_share", "hyv_area_share",
           "yield_total_t_per_acre", "yield_bcast_t_per_acre", "yield_ltrans_t_per_acre", "yield_hyv_t_per_acre", "yield_total_kg_per_ha",
           "nat_total_area", "nat_total_prod", "nat_yield_total_t_per_acre", "nat_hyv_share_area", "nat_bcast_share_area",
           "area_share_of_national", "prod_share_of_national", "yield_vs_national",
           "total_area_lag1", "total_area_lag2", "total_area_roll3_prev_mean", "total_area_yoy_pct",
           "total_prod_lag1", "total_prod_lag2", "total_prod_roll3_prev_mean", "total_prod_yoy_pct",
           "yield_total_t_per_acre_lag1", "yield_total_t_per_acre_lag2", "yield_total_t_per_acre_roll3_prev_mean", "yield_total_t_per_acre_yoy_pct",
           "hyv_area_share_lag1", "hyv_area_share_lag2", "hyv_area_share_roll3_prev_mean", "entity_hist_mean_yield",
           "is_cultivated", "dq_flags_str", "target_total_prod_next_year", "target_yield_next_year"]
ml[ML_COLS].to_csv(f"{OUT}/amon_rice_ml_ready_district_panel.csv", index=False)

# ------------------------------------------------------------------ harmonised panel 1979-80 .. 2014-15 (21 groups: hill tracts merged)
base = dist[dist.district_system != "20/21-district"].copy()
base["panel_group"] = base.legacy_group_23.where(~base.legacy_group_23.isin(HILL), "Chittagong Hill Tracts")
vals = [f"{k}_{m}" for k in COMPS for m in ("area", "prod")]
agg = (base.groupby(["panel_group", "fiscal_year", "year_start"], as_index=False)
       .agg(**{c: (c, lambda x: x.sum(min_count=len(x))) for c in vals},
            n_components=("district_std", "nunique"), src_system=("district_system", "first"),
            flags=("dq_flags_str", lambda s: ";".join(sorted({f for x in s for f in str(x).split(";") if f and f != "nan"})))))
agg["total_area"] = agg.bcast_area + agg.ltrans_area + agg.hyv_area + agg.pajam_area
agg["total_prod"] = agg.bcast_prod + agg.ltrans_prod + agg.hyv_prod + agg.pajam_prod
agg["district_std"] = agg.panel_group; agg["district_system"] = "21-group-harmonised"
agg["legacy_group_23"] = agg.panel_group
agg["division"] = agg.panel_group.map(lambda g: "Chittagong" if g == "Chittagong Hill Tracts" else G2DIV[g])
agg["is_aggregated_from_64"] = agg.src_system == "64-district"
agg["source_table"] = ""; agg["label_repaired"] = False
agg["record_id"] = "P21|" + agg.fiscal_year + "|" + agg.panel_group
agg["is_cultivated"] = agg.total_area > 0; agg["dq_flags_str"] = agg.flags
pan = features(agg, ["district_system", "district_std"], nat)
PCOLS = [c for c in ML_COLS if c in pan.columns] + ["n_components", "is_aggregated_from_64"]
pan[PCOLS].to_csv(f"{OUT}/amon_rice_panel_21groups_1979_2015.csv", index=False)

# ------------------------------------------------------------------ report numbers
rep = {}
print("rows master/ml/panel:", len(master), len(ml), len(pan))
print(master.dq_flags_str.str.split(";").explode().replace("", np.nan).dropna().value_counts().to_string())
nb = sum(sum(1 for v in json.loads(s) if v != "") for s in aud.raw_cells)
print("non-blank raw cells:", nb, "| printed values in master:", int(master[PRINTED].notna().sum().sum()))
dsum = df[d_ok].groupby("fiscal_year")[["total_area_clean", "total_prod_clean"]].sum()
nn = df[natmask].set_index("fiscal_year")[["total_area_clean", "total_prod_clean"]]
print("district sum vs national clean max abs diff:", (dsum - nn).abs().max().to_dict())
df.to_pickle("/tmp/amon_final.pkl")
rep_tbl.to_pickle("/tmp/amon_repairs.pkl")
