import json, os, re
import numpy as np, pandas as pd
from parse_boro import main as parse_pdf

OUT = "/mnt/user-data/outputs"
os.makedirs(OUT, exist_ok=True)
ACRE_TO_HA = 0.40468564224
COMPS = ["local", "hyv", "pajam", "hybrid"]
RAW = [f"{c}_{m}" for c in COMPS for m in ("area", "prod")] + ["total_area", "total_prod"]

df, aud = parse_pdf()
for c in RAW:
    if c not in df: df[c] = np.nan
df = df.reset_index(drop=True)
df["dq_flags"] = df.dq_flags.apply(list)
def flag(mask, text):
    for i in df.index[mask]: df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [text]

# ------------------------------------------------------------------ names / year / system
STD = {"Bakergonj": "Barisal", "Barissal": "Barisal", "Khustia": "Kushtia", "Mymenshing": "Mymensingh", "Kishoregonj": "Kishoreganj",
       "Sunamgonj": "Sunamganj", "Hobigonj": "Habiganj", "Maulavibazar": "Moulvibazar", "Manikgonj": "Manikganj",
       "Munshigonj": "Munshiganj", "Munsigonj": "Munshiganj", "Narayangonj": "Narayanganj", "Gopalgonj": "Gopalganj",
       "Perojpur": "Pirojpur", "Noagaon": "Naogaon", "Nawabgonj": "Nawabganj", "Sirajgonj": "Sirajganj",
       "Jhalakathi": "Jhalokati", "BANGLADESH": "Bangladesh", "Khunna Division": "Khulna Division"}
def std_name(n):
    k = re.sub(r"[\s\.]", "", n).lower()
    if k == "chittagonght": return "Chittagong Hill Tracts"
    return STD.get(n, n)
df["district_std"] = df.district_raw.map(std_name)
df["year_start"] = df.fiscal_year.str[:4].astype(int)
df["district_system"] = np.where(df.year_start < 1979, "20/21-district", np.where(df.year_start < 2006, "23-district", "64-district"))
df["has_pajam_col"] = df.cats.str.contains("pajam"); df["has_hybrid_col"] = df.cats.str.contains("hybrid")
df["label_repaired"] = False; df["label_repair_note"] = ""

# ------------------------------------------------------------------ R0. 2006-07: Dinajpur/Thakurgaon/Panchagar are printed twice
m = (df.fiscal_year == "2006-07") & (df.row_type == "district") & df.district_std.isin(["Dinajpur", "Thakurgaon", "Panchagar"]) & df.sl_no.isin(["51", "52", "53"])
assert m.sum() == 3
df.loc[m, "row_type"] = "duplicate_row"
flag(m, "src_duplicate_row_printed_inside_rajshahi_block")
flag((df.fiscal_year == "2006-07") & (df.row_type == "division_subtotal") & (df.district_std == "Rajshahi Division"), "src_division_total_includes_3_rangpur_division_districts")

# ------------------------------------------------------------------ R1. 2014-15 label/row shifts (verified exactly by sums below)
FIX_1415 = {"Kishoreganj": "Jamalpur", "Tangail": "Sherpur", "Dhaka Division": "Kishoreganj", "Jamalpur": "Netrokona", "Netrokona": "Tangail",
            "Sherpur": "Mymensingh", "Mymensingh": "@Dhaka Division", "Mymensingh Division": "Barisal", "Barisal": "Jhalokati",
            "Jhalokati": "Pirojpur", "Pirojpur": "Bhola", "Bhola": "Patuakhali", "Patuakhali": "Barguna", "Barguna": "@Barisal Division",
            "Barisal Division": "Jessore", "Jessore": "Jhenaidah", "Jhenaidah": "Magura", "Magura": "Narail", "Narail": "Khulna",
            "Khulna": "Bagerhat", "Bagerhat": "Satkhira", "Satkhira": "Kushtia", "Kushtia": "!JUNK"}
idxs = df.index[(df.fiscal_year == "2014-15") & (df.row_type.isin(["district", "division_subtotal"]))]
old = {i: df.at[i, "district_std"] for i in idxs}
for i in idxs:
    o = old[i]
    if o in FIX_1415:
        new = FIX_1415[o]; printed = df.at[i, "district_raw"]
        if new.startswith("@"): df.at[i, "district_std"] = new[1:]; df.at[i, "row_type"] = "division_subtotal"
        elif new == "!JUNK": df.at[i, "row_type"] = "junk_row"; df.at[i, "district_std"] = "(junk: copy of Bandarban values)"
        else: df.at[i, "district_std"] = new; df.at[i, "row_type"] = "district"
        df.at[i, "label_repaired"] = True; df.at[i, "label_repair_note"] = f"printed '{printed}' -> '{df.at[i, 'district_std']}'"
        df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["label_repaired_2014_15_verified_by_sums"]
j = df.index[(df.fiscal_year == "2014-15") & (df.row_type == "junk_row")]; assert len(j) == 1
b = df.index[(df.fiscal_year == "2014-15") & (df.district_std == "Bandarban")][0]
assert all(df.at[j[0], c] == df.at[b, c] for c in ["local_area", "hyv_area", "hybrid_area", "total_area", "total_prod"])
flag((df.fiscal_year == "2014-15") & (df.district_std == "Dhaka Division") & (df.row_type == "division_subtotal"),
     "note_printed_as_combined_dhaka_plus_new_mymensingh_division")

# ------------------------------------------------------------------ geography (division scheme from the PDF's own 2012-13 table)
G23 = {
 "Bandarban": ["Bandarban"], "Chittagong": ["Chittagong", "Cox's Bazar"], "Comilla": ["Comilla", "Chandpur", "Brahmanbaria"],
 "Khagrachari": ["Khagrachari"], "Noakhali": ["Noakhali", "Lakshmipur", "Feni"], "Rangamati": ["Rangamati"],
 "Sylhet": ["Sylhet", "Moulvibazar", "Sunamganj", "Habiganj"],
 "Dhaka": ["Dhaka", "Gazipur", "Manikganj", "Munshiganj", "Narayanganj", "Narsingdi"],
 "Faridpur": ["Faridpur", "Rajbari", "Madaripur", "Gopalganj", "Shariatpur"], "Jamalpur": ["Jamalpur", "Sherpur"],
 "Kishoreganj": ["Kishoreganj", "Netrokona"], "Mymensingh": ["Mymensingh"], "Tangail": ["Tangail"],
 "Barisal": ["Barisal", "Jhalokati", "Pirojpur", "Bhola"], "Jessore": ["Jessore", "Jhenaidah", "Magura", "Narail"],
 "Khulna": ["Khulna", "Bagerhat", "Satkhira"], "Kushtia": ["Kushtia", "Chuadanga", "Meherpur"],
 "Patuakhali": ["Patuakhali", "Barguna"], "Bogra": ["Bogra", "Joypurhat"], "Dinajpur": ["Dinajpur", "Thakurgaon", "Panchagar"],
 "Pabna": ["Pabna", "Sirajganj"], "Rajshahi": ["Rajshahi", "Naogaon", "Natore", "Nawabganj"],
 "Rangpur": ["Rangpur", "Gaibandha", "Kurigram", "Nilphamari", "Lalmonirhat"]}
D2G = {d: g for g, ds in G23.items() for d in ds}; assert len(D2G) == 64
HILL = {"Bandarban", "Khagrachari", "Rangamati", "Chittagong Hill Tracts"}
t = df[df.fiscal_year == "2012-13"].reset_index(drop=True)
div, pend = {}, []
for _, r in t.iterrows():
    if r.row_type == "district": pend.append(r.district_std)
    elif r.row_type == "division_subtotal":
        for d in pend: div[d] = r.district_std.replace(" Division", "")
        pend = []
assert len(div) == 64, len(div)
G2DIV = {}
for g, ds in G23.items():
    s = {div[d] for d in ds}; assert len(s) == 1, (g, s); G2DIV[g] = s.pop()
OLD_DIV = {"Chittagong Hill Tracts": "Chittagong"}
def division_of(r):
    if r.row_type != "district": return np.nan
    if r.district_system == "64-district": return div[r.district_std]
    return G2DIV.get(r.district_std, OLD_DIV.get(r.district_std, np.nan))
def group_of(r):
    if r.row_type != "district": return np.nan
    return D2G[r.district_std] if r.district_system == "64-district" else r.district_std
df["division"] = df.apply(division_of, axis=1)
df["legacy_group_23"] = df.apply(group_of, axis=1)

# ------------------------------------------------------------------ identity checks that validate the 2014-15 repair
x = df[(df.fiscal_year == "2014-15")]
dsum = x[x.row_type == "district"].total_area.sum(); nat = x[x.row_type == "national_total"].total_area.iloc[0]
assert dsum == nat, (dsum, nat)                                                   # 64 districts add up to the national total exactly
for dn in ["Chittagong", "Sylhet", "Dhaka", "Barisal", "Khulna", "Rajshahi", "Rangpur"]:
    s = x[(x.row_type == "district") & (x.division == dn)].total_area.sum()
    p = x[(x.row_type == "division_subtotal") & (x.district_std == f"{dn} Division")].total_area
    assert len(p) == 1 and p.iloc[0] == s, (dn, s, p.tolist())                     # every division row equals the sum of its districts

# ------------------------------------------------------------------ clean component columns
dist_mask = df.row_type == "district"
for c in COMPS:
    for q in ("area", "prod"):
        df[f"{c}_{q}_clean"] = df[f"{c}_{q}"].astype(float)
# a component cell is only "present" in the eras that print that column
for c in ("pajam", "hybrid"):
    df.loc[~df[f"has_{c}_col"], [f"{c}_area_clean", f"{c}_prod_clean"]] = np.nan

# R2. typos: neighbour-year yield test, digit-shift repair (x10 / :10) else null the variety's cells
MINA = {"local": 1500, "hyv": 15000, "pajam": 1500, "hybrid": 3000}
def nb_vals(i, comp, q=None):
    """neighbouring-year (area, prod) of the same district from the PRINTED values; neighbours must agree with each other"""
    r = df.loc[i]; out = []
    for dy in (-1, 1):
        j = df.index[(df.district_std == r.district_std) & (df.district_system == r.district_system) & (df.year_start == r.year_start + dy) & (df.row_type == "district")]
        if len(j):
            a, p = df.at[j[0], f"{comp}_area"], df.at[j[0], f"{comp}_prod"]
            if pd.notna(a) and pd.notna(p) and a > 0 and p > 0: out.append((a, p))
    if len(out) == 2:
        y1, y2 = out[0][1] / out[0][0], out[1][1] / out[1][0]
        if abs(np.log(y1 / y2)) > 0.35: return []                       # neighbours disagree with each other -> no reliable reference
    return out
repairs = []
for comp in COMPS:
    a, p = f"{comp}_area_clean", f"{comp}_prod_clean"
    y = df[p] / df[a].where(df[a] > 0)
    med = y[dist_mask].groupby(df.fiscal_year[dist_mask]).median()
    rel = y / df.fiscal_year.map(med)
    cand = []
    for i in df.index[dist_mask & df[a].notna()]:
        A, P = df.at[i, a], df.at[i, p]
        if comp in ("pajam", "hybrid") and not df.at[i, f"has_{comp}_col"]: continue
        if A == 0 and P > 0: cand.append((i, "prod_without_area")); continue
        if A < 1000 or not (A > 0 and P > 0): continue
        yi = P / A; nbs = nb_vals(i, comp)
        extreme = (rel[i] < 0.4) or (rel[i] > 2.5)
        anomaly = False
        if nbs and comp in ("hyv", "hybrid") and A >= MINA[comp]:
            nby = np.mean([pp / aa for aa, pp in nbs]); r_ = yi / nby
            if r_ < 0.7 or r_ > 1.4:
                dA = min(abs(np.log(A / aa)) for aa, _ in nbs); dP = min(abs(np.log(P / pp)) for _, pp in nbs)
                if max(dA, dP) > 0.35 and min(dA, dP) < 0.25: anomaly = True       # exactly one of the two cells disagrees with its neighbours
        if extreme or anomaly: cand.append((i, "yield"))
    for i, kind in cand:
        A, P = df.at[i, a], df.at[i, p]
        if kind == "prod_without_area":
            df.at[i, a] = np.nan; df.at[i, p] = np.nan
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"suspect_unrecoverable_{comp}_prod_without_area_nulled"]
            repairs.append((df.at[i, "fiscal_year"], df.at[i, "district_std"], comp, "NULLED(prod without area)", A, P, np.nan, np.nan)); continue
        nbs = nb_vals(i, comp)
        nby = np.mean([pp / aa for aa, pp in nbs]) if nbs else np.nan
        dA = min(abs(np.log(A / aa)) for aa, _ in nbs) if nbs else 0; dP = min(abs(np.log(P / pp)) for _, pp in nbs) if nbs else 0
        which = "area" if dA > dP else "prod"
        opts = [("area_x10", A * 10, P), ("area_div10", A / 10, P)] if which == "area" else [("prod_x10", A, P * 10), ("prod_div10", A, P / 10)]
        good = []
        for lab, na, np_ in opts:
            if na != int(na) or np_ != int(np_): continue
            yy = np_ / na
            ref = nby if pd.notna(nby) else float(med[df.at[i, "fiscal_year"]])
            if not (0.6 * ref <= yy <= 1.5 * ref): continue
            val = na if which == "area" else np_
            nbq = [aa if which == "area" else pp for aa, pp in nbs]
            dist = min(abs(np.log(val / n)) for n in nbq) if nbq else np.inf
            good.append((dist, lab, na, np_))
        good.sort()
        if good and good[0][0] < np.log(1.3):
            _, lab, na, np_ = good[0]
            df.at[i, a], df.at[i, p] = na, np_
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"adj_{comp}_{lab}"]
            repairs.append((df.at[i, "fiscal_year"], df.at[i, "district_std"], comp, lab, A, P, na, np_))
        else:
            df.at[i, a] = np.nan; df.at[i, p] = np.nan
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"suspect_unrecoverable_{comp}_nulled"]
            repairs.append((df.at[i, "fiscal_year"], df.at[i, "district_std"], comp, "NULLED", A, P, np.nan, np.nan))
rep_tbl = pd.DataFrame(repairs, columns=["fy", "district", "component", "action", "area_raw", "prod_raw", "area_clean", "prod_clean"]).sort_values(["fy", "district"])
print(rep_tbl.to_string())

# totals = sum of the varieties present in that era (NaN if any present variety is NaN)
def comp_sum(d, which):
    tot = pd.Series(0.0, index=d.index); bad = pd.Series(False, index=d.index)
    for c in COMPS:
        present = True if c in ("local", "hyv") else d[f"has_{c}_col"]
        v = d[f"{c}_{which}_clean"]
        if c in ("local", "hyv"):
            bad |= v.isna(); tot += v.fillna(0)
        else:
            bad |= (present & v.isna()); tot += v.fillna(0)
    return tot.where(~bad)
for w in ("area", "prod"):
    df[f"total_{w}_clean"] = comp_sum(df, w)
z = lambda c: df[c].fillna(0)
df["total_area_calc_printed"] = sum(z(f"{c}_area") for c in COMPS); df["total_prod_calc_printed"] = sum(z(f"{c}_prod") for c in COMPS)
df["chk_area_printed_minus_calc"] = df.total_area - df.total_area_calc_printed
df["chk_prod_printed_minus_calc"] = df.total_prod - df.total_prod_calc_printed
flag((df.chk_area_printed_minus_calc.abs() > 1) | (df.chk_prod_printed_minus_calc.abs() > 1), "src_printed_total_not_equal_sum_of_parts")
flag(dist_mask & (df.total_area == 0) & (df.total_area_clean > 0), "printed_total_area_zero_filled_from_components")

# ------------------------------------------------------------------ aggregates (clean)
natmask = df.row_type == "national_total"
FILL = {}
for c in COMPS:
    for q in ("area", "prod"):
        col = f"{c}_{q}"; FILL[col] = df[f"{col}_clean"].where(df[f"{col}_clean"].notna(), df[col])
for fy in df.fiscal_year.unique():
    sel = dist_mask & (df.fiscal_year == fy)
    ni = df.index[natmask & (df.fiscal_year == fy)]; assert len(ni) == 1, fy
    has_p, has_h = df.at[ni[0], "has_pajam_col"], df.at[ni[0], "has_hybrid_col"]
    for c in COMPS:
        if (c == "pajam" and not has_p) or (c == "hybrid" and not has_h): continue
        for q in ("area", "prod"): df.at[ni[0], f"{c}_{q}_clean"] = FILL[f"{c}_{q}"][sel].sum()
    for w in ("area", "prod"):
        df.at[ni[0], f"total_{w}_clean"] = sum(df.at[ni[0], f"{c}_{w}_clean"] for c in COMPS if pd.notna(df.at[ni[0], f"{c}_{w}_clean"]))
for fy in ["2006-07", "2012-13", "2013-14", "2014-15"]:
    for i in df.index[(df.fiscal_year == fy) & (df.row_type == "division_subtotal")]:
        dn = df.at[i, "district_std"].replace(" Division", "")
        sel = dist_mask & (df.fiscal_year == fy) & (df.division == dn)
        has_p, has_h = df.at[i, "has_pajam_col"], df.at[i, "has_hybrid_col"]
        for c in COMPS:
            if (c == "pajam" and not has_p) or (c == "hybrid" and not has_h): continue
            for q in ("area", "prod"): df.at[i, f"{c}_{q}_clean"] = FILL[f"{c}_{q}"][sel].sum()
        for w in ("area", "prod"):
            df.at[i, f"total_{w}_clean"] = sum(df.at[i, f"{c}_{w}_clean"] for c in COMPS if pd.notna(df.at[i, f"{c}_{w}_clean"]))
        if abs(df.at[i, "total_area_clean"] - df.at[i, "total_area"]) > 1 or abs(df.at[i, "total_prod_clean"] - df.at[i, "total_prod"]) > 1:
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["division_total_recomputed_differs_from_printed"]
chk = df[natmask]
for c in RAW:
    d = (chk[c] - chk[f"{c}_clean"]).abs()
    for i in chk.index[(d > 1) & chk[c].notna() & chk[f"{c}_clean"].notna()]:
        df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"src_national_printed_{c}_differs_from_district_sum"]

# ------------------------------------------------------------------ structural notes
cht_yrs = ["1980-81", "1981-82", "1982-83", "1983-84"]
flag(dist_mask & (df.district_std == "Rangamati") & df.fiscal_year.isin(cht_yrs), "src_note_cht_figures_shown_against_rangamati")
flag(dist_mask & (df.district_std == "Chittagong Hill Tracts") & (df.fiscal_year == "1979-80"), "src_note_cht_single_row_1979_80")
flag(dist_mask & df.district_std.isin(["Bandarban", "Khagrachari"]) & df.fiscal_year.isin(cht_yrs) & (df.total_area_clean == 0), "structural_zero_cht_counted_under_rangamati")
flag(dist_mask & (df.year_start <= 1978) & (df.total_area_clean == 0), "structural_zero_not_yet_separate_district")
flag(dist_mask & (df.year_start == 2006), "note_hybrid_included_in_hyv_2006_07")
flag(df.dq_flags.apply(lambda f: "last_col_cell_merged" in f), "note_cell_fragments_rejoined")

# ------------------------------------------------------------------ yields
def add_yields(d):
    pa = lambda p, a: np.where(d[a] > 0, d[p] / d[a], np.nan)
    d["yield_total_t_per_acre"] = pa("total_prod_clean", "total_area_clean")
    d["yield_local_t_per_acre"] = pa("local_prod_clean", "local_area_clean")
    d["yield_hyv_t_per_acre"] = pa("hyv_prod_clean", "hyv_area_clean")
    d["yield_hybrid_t_per_acre"] = pa("hybrid_prod_clean", "hybrid_area_clean")
    d["yield_total_kg_per_ha"] = d.yield_total_t_per_acre * 1000 / ACRE_TO_HA
    return d
df = add_yields(df)
dd = df[dist_mask & (df.total_area_clean >= 2000)]
med = dd.groupby("fiscal_year").yield_total_t_per_acre.median()
rel = dd.yield_total_t_per_acre / dd.fiscal_year.map(med)
for i in dd.index[(rel < 0.35) | (rel > 2.0)]:
    df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["yield_outlier_review"]
df["is_cultivated"] = df.total_area_clean > 0
df["dq_flags_str"] = df.dq_flags.apply(lambda f: ";".join(sorted(set(f))))
df["record_id"] = df.source_table + "|" + df.fiscal_year + "|" + df.district_raw.str.replace(r"\s+", "_", regex=True) + "|" + df.sl_no.str.replace("/", "_")

PRINTED = RAW
CLEAN = [f"{c}_{m}_clean" for c in COMPS for m in ("area", "prod")] + ["total_area_clean", "total_prod_clean"]
MASTER_COLS = (["record_id", "source_table", "source_pdf_page", "sl_no", "fy_label_raw", "fiscal_year", "year_start", "district_raw",
                "district_std", "label_repaired", "label_repair_note", "row_type", "district_system", "division", "legacy_group_23",
                "has_pajam_col", "has_hybrid_col"] + PRINTED + ["chk_area_printed_minus_calc", "chk_prod_printed_minus_calc"] + CLEAN +
               ["yield_total_t_per_acre", "yield_local_t_per_acre", "yield_hyv_t_per_acre", "yield_hybrid_t_per_acre",
                "yield_total_kg_per_ha", "is_cultivated", "dq_flags_str"])
master = df[MASTER_COLS].copy()
for c in PRINTED + ["chk_area_printed_minus_calc", "chk_prod_printed_minus_calc"]: master[c] = master[c].astype("Int64")
for c in CLEAN: master[c] = master[c].round(0).astype("Int64")
master.to_csv(f"{OUT}/boro_rice_master_long.csv", index=False)
aud.rename(columns={"table": "source_table", "pdf_page": "source_pdf_page", "name": "row_name_raw", "fy": "fiscal_year_assigned"}).to_csv(f"{OUT}/boro_rice_raw_cells_audit.csv", index=False)

# ------------------------------------------------------------------ ML features
def features(d, ent, nat):
    d = d.sort_values(ent + ["year_start"]).reset_index(drop=True)
    for c in ("pajam", "hybrid"):
        for q in ("area", "prod"): d[f"{c}_{q}"] = d[f"{c}_{q}"].fillna(0)
    d["nonlocal_area"] = d.total_area - d.local_area; d["nonlocal_prod"] = d.total_prod - d.local_prod
    d["hybrid_recorded"] = (d.year_start >= 2007).astype(int)
    ta = d.total_area.where(d.total_area > 0)
    d["local_area_share"] = d.local_area / ta; d["hyv_area_share"] = d.hyv_area / ta
    d["pajam_area_share"] = d.pajam_area / ta; d["hybrid_area_share"] = d.hybrid_area / ta; d["nonlocal_area_share"] = d.nonlocal_area / ta
    d["yield_total_t_per_acre"] = np.where(d.total_area > 0, d.total_prod / d.total_area, np.nan)
    d["yield_local_t_per_acre"] = np.where(d.local_area > 0, d.local_prod / d.local_area, np.nan)
    d["yield_hyv_t_per_acre"] = np.where(d.hyv_area > 0, d.hyv_prod / d.hyv_area, np.nan)
    d["yield_hybrid_t_per_acre"] = np.where(d.hybrid_area > 0, d.hybrid_prod / d.hybrid_area, np.nan)
    d["yield_total_kg_per_ha"] = d.yield_total_t_per_acre * 1000 / ACRE_TO_HA
    d["area_ha"] = d.total_area * ACRE_TO_HA
    d = d.merge(nat, on="year_start", how="left")
    d["area_share_of_national"] = d.total_area / d.nat_total_area
    d["prod_share_of_national"] = d.total_prod / d.nat_total_prod
    d["yield_vs_national"] = d.yield_total_t_per_acre / d.nat_yield_total_t_per_acre
    d["_seg"] = (d.groupby(ent).year_start.diff().fillna(1) != 1).groupby([d[e] for e in ent]).cumsum()      # new segment after a gap in years
    g = d.groupby(ent + ["_seg"], sort=False)
    for c in ["total_area", "total_prod", "yield_total_t_per_acre", "nonlocal_area_share"]:
        s = g[c]; d[f"{c}_lag1"] = s.shift(1); d[f"{c}_lag2"] = s.shift(2)
        d[f"{c}_roll3_prev_mean"] = s.transform(lambda x: x.shift(1).rolling(3, min_periods=1).mean())
    for c in ["total_area", "total_prod", "yield_total_t_per_acre"]:
        d[f"{c}_yoy_pct"] = np.where(d[f"{c}_lag1"] > 0, (d[c] / d[f"{c}_lag1"] - 1) * 100, np.nan)
    d["entity_hist_mean_yield"] = g["yield_total_t_per_acre"].transform(lambda x: x.shift(1).expanding().mean())
    d["t_index"] = d.year_start - d.year_start.min(); d["decade"] = (d.year_start // 10) * 10
    d["post_liberation"] = (d.year_start >= 1971).astype(int)
    d["target_total_prod_next_year"] = g["total_prod"].shift(-1)
    d["target_yield_next_year"] = g["yield_total_t_per_acre"].shift(-1)
    d["entity_id"] = d[ent].astype(str).agg("|".join, axis=1)
    d = d.drop(columns="_seg")
    return d

nr = df[natmask].drop_duplicates("year_start")
nat = pd.DataFrame({"year_start": nr.year_start, "nat_total_area": nr.total_area_clean, "nat_total_prod": nr.total_prod_clean,
                    "nat_local_share_area": nr.local_area_clean / nr.total_area_clean})
nat["nat_yield_total_t_per_acre"] = nat.nat_total_prod / nat.nat_total_area

def rename_clean(d): return d.rename(columns={f"{c}_clean": c for c in [f"{k}_{m}" for k in COMPS for m in ("area", "prod")] + ["total_area", "total_prod"]})
dist = rename_clean(df[dist_mask][["record_id", "fiscal_year", "year_start", "district_system", "district_std", "division", "legacy_group_23",
                                   "source_table", "label_repaired", "is_cultivated", "dq_flags_str"] + CLEAN].copy())
ml = features(dist, ["district_system", "district_std"], nat)
ML_COLS = ["record_id", "entity_id", "fiscal_year", "year_start", "t_index", "decade", "post_liberation", "district_system", "district_std",
           "division", "legacy_group_23", "source_table", "label_repaired", "hybrid_recorded",
           "local_area", "local_prod", "hyv_area", "hyv_prod", "pajam_area", "pajam_prod", "hybrid_area", "hybrid_prod",
           "nonlocal_area", "nonlocal_prod", "total_area", "area_ha", "total_prod",
           "local_area_share", "hyv_area_share", "pajam_area_share", "hybrid_area_share", "nonlocal_area_share",
           "yield_total_t_per_acre", "yield_local_t_per_acre", "yield_hyv_t_per_acre", "yield_hybrid_t_per_acre", "yield_total_kg_per_ha",
           "nat_total_area", "nat_total_prod", "nat_yield_total_t_per_acre", "nat_local_share_area",
           "area_share_of_national", "prod_share_of_national", "yield_vs_national",
           "total_area_lag1", "total_area_lag2", "total_area_roll3_prev_mean", "total_area_yoy_pct",
           "total_prod_lag1", "total_prod_lag2", "total_prod_roll3_prev_mean", "total_prod_yoy_pct",
           "yield_total_t_per_acre_lag1", "yield_total_t_per_acre_lag2", "yield_total_t_per_acre_roll3_prev_mean", "yield_total_t_per_acre_yoy_pct",
           "nonlocal_area_share_lag1", "nonlocal_area_share_lag2", "nonlocal_area_share_roll3_prev_mean", "entity_hist_mean_yield",
           "is_cultivated", "dq_flags_str", "target_total_prod_next_year", "target_yield_next_year"]
ml[ML_COLS].to_csv(f"{OUT}/boro_rice_ml_ready_district_panel.csv", index=False)

# ------------------------------------------------------------------ harmonised panel 1979-80 .. 2014-15 (21 groups: hill tracts merged)
base = dist[dist.district_system != "20/21-district"].copy()
base["panel_group"] = base.legacy_group_23.where(~base.legacy_group_23.isin(HILL), "Chittagong Hill Tracts")
vals = [f"{k}_{m}" for k in COMPS for m in ("area", "prod")]
agg = (base.groupby(["panel_group", "fiscal_year", "year_start"], as_index=False)
       .agg(**{c: (c, lambda x: x.sum(min_count=1) if x.notna().any() else np.nan) for c in vals},
            n_components=("district_std", "nunique"), src_system=("district_system", "first"),
            flags=("dq_flags_str", lambda s: ";".join(sorted({f for x in s for f in str(x).split(";") if f and f != "nan"})))))
# a NULLed variety inside a group makes the group's variety/total NaN
nullgrp = base.groupby(["panel_group", "fiscal_year"]).apply(lambda g: g[[f"{c}_area" for c in ("local", "hyv")]].isna().any().any()).rename("has_null").reset_index()
agg = agg.merge(nullgrp, on=["panel_group", "fiscal_year"])
agg["total_area"] = agg.local_area + agg.hyv_area + agg.pajam_area.fillna(0) + agg.hybrid_area.fillna(0)
agg["total_prod"] = agg.local_prod + agg.hyv_prod + agg.pajam_prod.fillna(0) + agg.hybrid_prod.fillna(0)
for c in ("total_area", "total_prod"): agg.loc[agg.has_null, c] = np.nan
agg["district_std"] = agg.panel_group; agg["district_system"] = "21-group-harmonised"; agg["legacy_group_23"] = agg.panel_group
agg["division"] = agg.panel_group.map(lambda g: "Chittagong" if g == "Chittagong Hill Tracts" else G2DIV[g])
agg["is_aggregated_from_64"] = agg.src_system == "64-district"
agg["source_table"] = ""; agg["label_repaired"] = False
agg["record_id"] = "P21|" + agg.fiscal_year + "|" + agg.panel_group
agg["is_cultivated"] = agg.total_area > 0; agg["dq_flags_str"] = agg.flags
pan = features(agg, ["district_system", "district_std"], nat)
PCOLS = [c for c in ML_COLS if c in pan.columns] + ["n_components", "is_aggregated_from_64"]
pan[PCOLS].to_csv(f"{OUT}/boro_rice_panel_21groups_1979_2015.csv", index=False)

# ------------------------------------------------------------------ report numbers
print("rows master/ml/panel:", len(master), len(ml), len(pan))
print(master.dq_flags_str.str.split(";").explode().replace("", np.nan).dropna().value_counts().to_string())
nb = sum(sum(1 for v in json.loads(s) if v != "") for s in aud.raw_cells)
print("non-blank raw cells:", nb, "| printed values in master:", int(master[PRINTED].notna().sum().sum()))
df.to_pickle("/tmp/boro_final.pkl"); rep_tbl.to_pickle("/tmp/boro_repairs.pkl")
