"""Parse 'Estimates of Potato' tables 3.1 - 3.33 (BBS, 45 years Agriculture Statistics).
Area in acres, production in metric tons ('M tons')."""
import re, json
import pdfplumber
import numpy as np
import pandas as pd

PDF = "/mnt/user-data/uploads/45_years_of_Major_Crops_Potato_.pdf"
# era -> (varieties per year in column order)
ERAS = {"A": ["total"], "B": ["local", "hyv", "indian", "total"], "C": ["local", "hyv", "total"], "D": ["local", "hyv", "total"]}
LAYOUT = []   # (page, table idx on page, years, era, continuation)
def add(p, i, ys, era, cont=False): LAYOUT.append((p, i, ys, era, cont))
add(1, 0, ["1969-70", "1970-71", "1971-72", "1972-73", "1973-74"], "A")
add(2, 0, ["1974-75", "1975-76"], "A")
add(3, 0, ["1976-77", "1977-78", "1978-79"], "A")
add(4, 0, ["1979-80", "1980-81", "1981-82"], "A")
b_years = ["1982-83", "1983-84", "1984-85", "1985-86", "1986-87", "1987-88", "1988-89", "1989-90", "1990-91", "1991-92", "1992-93",
           "1993-94", "1994-95", "1995-96", "1996-97", "1997-98", "1998-99", "1999-00", "2000-01", "2001-02", "2002-03"]
bp = {"1982-83": (5, 0), "1983-84": (6, 0), "1984-85": (6, 1), "1985-86": (7, 0), "1986-87": (8, 0), "1987-88": (9, 0), "1988-89": (10, 0),
      "1989-90": (11, 0), "1990-91": (12, 0), "1991-92": (12, 1), "1992-93": (13, 0), "1993-94": (13, 1), "1994-95": (14, 0), "1995-96": (14, 1),
      "1996-97": (15, 0), "1997-98": (15, 1), "1998-99": (16, 0), "1999-00": (16, 1), "2000-01": (17, 0), "2001-02": (17, 1), "2002-03": (18, 0)}
for y in b_years: add(bp[y][0], bp[y][1], [y], "B")
for pages, ys in [((19, 20, 21), ["2003-04", "2004-05"]), ((22, 23, 24), ["2005-06", "2006-07"]), ((25, 26, 27), ["2007-08", "2008-09"]),
                  ((28, 29, 30), ["2009-10", "2010-11"]), ((31, 32, 33), ["2011-12", "2012-13"])]:
    for k, p in enumerate(pages): add(p, 0, ys, "C", cont=k > 0)
add(34, 0, ["2013-14"], "D"); add(35, 0, ["2013-14"], "D", True)
add(36, 0, ["2014-15"], "D"); add(37, 0, ["2014-15"], "D", True)

def fix_name(parts):
    """Names are split over several cells; a wrapped 'Region' suffix is interleaved line by line (e.g. 'Kha/Regi' + 'grachari/on')."""
    parts = [p for p in parts if p]
    lines = [p.split("\n") for p in parts]
    if len(parts) > 1 and len({len(l) for l in lines}) == 1 and len(lines[0]) > 1:
        s = " ".join("".join(l[k] for l in lines) for k in range(len(lines[0])))
    else:
        s = "".join(re.sub(r"\s*\n\s*", " ", p) for p in parts)
    return re.sub(r"\s+", " ", s).strip()

def identity_ok(vals, era, ny):
    try: v = [int(x) for x in vals]
    except ValueError: return False
    k = len(ERAS[era])
    if k == 1: return True
    for y in range(ny):
        b = v[y * 2 * k:(y + 1) * 2 * k]
        for q in (0, 1):
            parts = sum(b[c * 2 + q] for c in range(k - 1)); tot = b[(k - 1) * 2 + q]
            if abs(parts - tot) > 1: return False
    return True

def text_lines(pdf, page_no, obj, next_top, N):
    p = pdf.pages[page_no - 1]
    crop = p.crop((obj.bbox[0] - 3, max(obj.bbox[1] - 3, 0), obj.bbox[2] + 3, next_top))
    out = []
    for line in (crop.extract_text() or "").split("\n"):
        toks = line.split(); nums = []
        while toks and re.fullmatch(r"\d+", toks[-1]): nums.append(toks.pop())
        nums = list(reversed(nums))
        if len(nums) >= N: out.append((" ".join(toks).strip(), nums[-N:]))
    return out

def main():
    pdf = pdfplumber.open(PDF)
    records, audit = [], []; order = 0
    for (page, idx, years, era, cont) in LAYOUT:
        pg = pdf.pages[page - 1]
        tabs = [(t, o) for t, o in zip(pg.extract_tables(), pg.find_tables()) if len(t) > 5]
        tab, obj = tabs[idx]
        next_top = (tabs[idx + 1][1].bbox[1] - 2) if idx + 1 < len(tabs) else pg.height
        cats = ERAS[era]; k = len(cats); ny = len(years); N = ny * k * 2
        tid = ""
        for r in tab[:3]:
            for c in r:
                m = re.search(r"Table:\s*(3\s?\.\d+)", str(c or ""))
                if m: tid = m.group(1).replace(" ", "")
        tl = text_lines(pdf, page, obj, next_top, N)
        txt_nums = [n for _, n in tl]
        grid_names = [re.sub(r"[^a-z]", "", fix_name([str(c or "") for c in r if re.search(r"[A-Za-z]", str(c or ""))]).lower()) for r in tab]
        extra_rows = []
        if not any(g.startswith("bangladesh") or g.startswith("bang") for g in grid_names):          # national row sits outside the grid
            nat = [n for pref, n in tl if pref.lower().startswith("bangladesh") and identity_ok(n, era, ny)]
            if nat: extra_rows.append(["BANGLADESH", None] + nat[0])
        for row in tab + extra_rows:
            cells = ["" if c is None else str(c).strip() for c in row]
            txt_idx = [i for i, c in enumerate(cells) if re.search(r"[A-Za-z]", c)]
            if not txt_idx: continue
            last_txt = max(txt_idx)
            nums = [re.sub(r"\s+", "", c) for c in cells[last_txt + 1:] if re.fullmatch(r"\d[\d\s]*", c)]
            if not nums: continue
            name = fix_name([cells[i] for i in txt_idx])
            if re.search(r"agriculture statistics|^estimates|^table", name, re.I): continue
            pre = [c for c in cells[:txt_idx[0]] if re.fullmatch(r"\d+\.?|0\d", c)]
            sl = pre[0].rstrip(".") if pre else ""
            raw = list(nums); flags = []
            slice_ = cells[last_txt + 1:]
            if len(slice_) == N and all(re.fullmatch(r"\d*", c) for c in slice_) and any(c == "" for c in slice_):
                vals = [re.sub(r"\s+", "", c) for c in slice_]; flags.append("blank_cell_in_source")     # exact cell positions kept
            else:
                vals = nums
            if len(vals) > N:                                   # numbers split over two cells -> merge adjacent fragments until identity holds
                done = False
                for cut in range(len(vals) - 1, 0, -1):
                    tryv = vals[:cut - 1] + [vals[cut - 1] + vals[cut]] + vals[cut + 1:]
                    if len(tryv) == N and identity_ok(tryv, era, ny): vals = tryv; flags.append("cell_fragments_rejoined"); done = True; break
                if not done:
                    vals = vals[:len(vals) - 2] + [vals[-2] + vals[-1]] if len(vals) == N + 1 else vals
            if "blank_cell_in_source" not in flags and (len(vals) != N or not identity_ok(vals, era, ny)):
                head = vals[:max(N - 2, 0)]
                cands = [t for t in txt_nums if t[:len(head)] == head and t != vals]
                good = [c for c in cands if identity_ok(c, era, ny)]
                if good: vals = good[0]; flags.append("values_taken_from_page_text")
                elif len(vals) != N: raise ValueError(f"p{page} {name}: expected {N} got {len(vals)} {raw}")
            if row in extra_rows: flags.append("row_read_from_page_text")
            audit.append(dict(table=tid, pdf_page=page, sl=sl, name=name, raw_cells=json.dumps(raw)))
            order += 1
            for yi, fy in enumerate(years):
                rec = dict(source_table=tid, source_pdf_page=page, fiscal_year=fy, district_raw=name, sl_no=sl, era=era, row_order=order, dq_flags=list(flags))
                b = vals[yi * k * 2:(yi + 1) * k * 2]
                for ci, cat in enumerate(cats):
                    toi = lambda v: int(v) if v != "" else np.nan
                    rec[f"{cat}_area"] = toi(b[ci * 2]); rec[f"{cat}_prod"] = toi(b[ci * 2 + 1])
                records.append(rec)
    df = pd.DataFrame(records)
    for c in ["local_area", "local_prod", "hyv_area", "hyv_prod", "indian_area", "indian_prod"]:
        if c not in df: df[c] = np.nan
    return df, pd.DataFrame(audit)

if __name__ == "__main__":
    df, aud = main()
    df.to_pickle("/tmp/potato_raw.pkl"); aud.to_pickle("/tmp/potato_audit.pkl")
    print(df.shape, aud.shape)
    print(df.groupby("fiscal_year").size().to_string())
    print(df.dq_flags.explode().value_counts())
