"""Parse 'Estimates of Jute' tables 2.1 - 2.14 (BBS, 45 years Agriculture Statistics).
Area in acres, production in bales (2012-13 .. 2014-15 headed 'M tons' but the magnitudes are bales)."""
import re, json
import pdfplumber
import numpy as np
import pandas as pd
from parse_amon import clean_cell, norm_name, HEAD, rows_of

PDF = "/mnt/user-data/uploads/45_years_of_Major_Crops_Jute_.pdf"
Y = lambda *a: list(a)
# (page, index of table on page, table id, years, values per year, district system, continuation of previous?)
LAYOUT = [
 (1, 0, "2.1", Y("1969-70", "1970-71", "1971-72"), 6, "20/21-district", False),
 (2, 0, "2.2", Y("1972-73", "1973-74", "1974-75"), 6, "20/21-district", False),
 (3, 0, "2.3", Y("1975-76", "1976-77", "1977-78"), 6, "20/21-district", False),
 (4, 0, "2.4", Y("1978-79"), 6, "20/21-district", False),
 (5, 0, "2.5", Y("1981-82", "1982-83"), 6, "23-district", False),
 (6, 0, "2.6", Y("1983-84", "1984-85"), 6, "23-district", False),
 (7, 0, "2.7", Y("1985-86", "1986-87"), 6, "23-district", False),
 (8, 0, "2.8", Y("1987-88", "1988-89"), 6, "23-district", False),
 (9, 0, "2.10", Y("1989-90", "1990-91", "1991-92", "1992-93", "1993-94", "1994-95"), 2, "23-district", False),
 (10, 0, "2.9", Y("1995-96", "1996-97", "1997-98", "1998-99", "1999-00", "2000-01"), 2, "23-district", False),
 (11, 0, "2.11", Y("2001-02", "2002-03", "2003-04"), 2, "23-district", False),
 (12, 0, "2.12", Y("2004-05", "2005-06", "2006-07", "2007-08"), 2, "64-district", False),
 (13, 0, "2.12", Y("2004-05", "2005-06", "2006-07", "2007-08"), 2, "64-district", True),
 (14, 0, "2.12", Y("2004-05", "2005-06", "2006-07", "2007-08"), 2, "64-district", True),
 (14, 1, "2.13", Y("2008-09", "2009-10", "2010-11", "2011-12"), 2, "64-district", False),
 (15, 0, "2.13", Y("2008-09", "2009-10", "2010-11", "2011-12"), 2, "64-district", True),
 (16, 0, "2.13", Y("2008-09", "2009-10", "2010-11", "2011-12"), 2, "64-district", True),
 (17, 0, "2.14", Y("2012-13", "2013-14", "2014-15"), 2, "64-district", False),
 (18, 0, "2.14", Y("2012-13", "2013-14", "2014-15"), 2, "64-district", True),
]
CATS6 = ["jute", "mesta", "total"]

def fy_of(raw): return raw

def text_rows(pdf, page_no, obj, next_top, N):
    p = pdf.pages[page_no - 1]
    crop = p.crop((obj.bbox[0] - 3, max(obj.bbox[1] - 3, 0), obj.bbox[2] + 3, next_top))
    out = []
    for line in (crop.extract_text() or "").split("\n"):
        toks = line.split(); nums = []
        while toks and re.fullmatch(r"\d+", toks[-1]): nums.append(toks.pop())
        nums = list(reversed(nums))
        if len(nums) >= N:
            pref = re.sub(r"^\d+\s+", "", " ".join(toks)).strip()
            out.append((pref, nums[-N:]))
    return out

def ident_ok(vals, nyear):
    """6-value years: total = jute + mesta (area and production), tolerance +-1"""
    try: v = [int(x) for x in vals]
    except ValueError: return False
    for y in range(nyear):
        b = v[y * 6:(y + 1) * 6]
        if abs(b[0] + b[2] - b[4]) > 1 or abs(b[1] + b[3] - b[5]) > 1: return False
    return True

def main():
    pdf = pdfplumber.open(PDF)
    records, audit = [], []
    order = 0
    for (page, idx, table, years, per, system, cont) in LAYOUT:
        pg = pdf.pages[page - 1]
        tabs = [(t, o) for t, o in zip(pg.extract_tables(), pg.find_tables()) if len(t) > 5]
        tab, obj = tabs[idx]
        next_top = (tabs[idx + 1][1].bbox[1] - 2) if idx + 1 < len(tabs) else pg.height
        ny = len(years); N = ny * per
        txt_rows = text_rows(pdf, page, obj, next_top, N)
        grid = list(rows_of(tab))
        seen = {re.sub(r"[^a-z]", "", n.lower()) + sl for sl, n, _ in grid}
        extra = []
        for pref, nums in txt_rows:                                   # rows outside the grid (glued to the page footer)
            k = re.sub(r"[^a-z]", "", pref.lower())
            if k and not any(k == re.sub(r"[^a-z]", "", n.lower()) for _, n, _ in grid) and pref.lower().startswith(("bangladesh",)):
                extra.append(("", pref, list(nums)))
        for sl, name, vals in grid + extra:
            is_extra = (sl, name, vals) in extra
            if not any(re.fullmatch(r"\d+", v) for v in vals): continue
            raw_vals = list(vals); flags = []
            if len(vals) != N:
                nb = [v for v in vals if v != ""]
                if len(nb) == N: vals = nb
                elif len(nb) == N + 1: vals = nb[:-2] + [nb[-2] + nb[-1]]; flags.append("last_col_cell_merged")
                else:
                    key = re.sub(r"[^a-z]", "", name.lower())
                    c = [n for pref, n in txt_rows if re.sub(r"[^a-z]", "", pref.lower()) == key]
                    if c: vals = c[0]; flags.append("values_taken_from_page_text")
                    else: raise ValueError(f"{table} p{page} {name}: expected {N} got {len(vals)} {raw_vals}")
            # cross-check with page text; use identity when available
            key = re.sub(r"[^a-z]", "", name.lower())
            cands = [n for pref, n in txt_rows if re.sub(r"[^a-z]", "", pref.lower()) == key and n != vals]
            if per == 6:
                if not ident_ok(vals, ny):
                    good = [c for c in cands if ident_ok(c, ny)]
                    if good: vals = good[0]; flags.append("values_taken_from_page_text")
            elif cands and any(not re.fullmatch(r"\d+", v) for v in vals):
                vals = cands[0]; flags.append("values_taken_from_page_text")
            if is_extra: flags.append("row_read_from_page_text")
            audit.append(dict(table=table, pdf_page=page, sl=sl, name=name, raw_cells=json.dumps(raw_vals)))
            order += 1
            for yi, fy in enumerate(years):
                rec = dict(source_table=table, source_pdf_page=page, fiscal_year=fy, district_raw=name, sl_no=sl.replace("\n", "/"),
                           district_system=system, row_order=order, per_year=per, dq_flags=list(flags))
                b = vals[yi * per:(yi + 1) * per]
                toi = lambda v: int(v) if v != "" else np.nan
                if any(v == "" for v in b): rec["dq_flags"] = rec["dq_flags"] + ["blank_cell_in_source"]
                if per == 6:
                    for ci, cat in enumerate(CATS6):
                        rec[f"{cat}_area"] = toi(b[ci * 2]); rec[f"{cat}_prod"] = toi(b[ci * 2 + 1])
                else:
                    rec["total_area"] = toi(b[0]); rec["total_prod"] = toi(b[1])
                records.append(rec)
    df = pd.DataFrame(records)
    for c in ["jute_area", "jute_prod", "mesta_area", "mesta_prod"]:
        if c not in df: df[c] = np.nan
    return df, pd.DataFrame(audit)

if __name__ == "__main__":
    df, aud = main()
    df.to_pickle("/tmp/jute_raw.pkl"); aud.to_pickle("/tmp/jute_audit.pkl")
    print(df.shape, aud.shape)
    print(df.groupby(["fiscal_year"]).size().to_string())
