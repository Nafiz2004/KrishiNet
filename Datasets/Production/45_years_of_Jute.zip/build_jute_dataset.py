import json, os, re
import numpy as np, pandas as pd
from parse_jute import main as parse_pdf

OUT = "/mnt/user-data/outputs"
os.makedirs(OUT, exist_ok=True)
VARS = ["jute", "mesta", "total"]
RAW = [f"{v}_{q}" for v in VARS for q in ("area", "prod")]

df, aud = parse_pdf()
df = df.sort_values("row_order", kind="stable").reset_index(drop=True)
df["dq_flags"] = df.dq_flags.apply(list)
def flag(mask, text):
    for i in df.index[mask]: df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [text]

# ------------------------------------------------------------------ names / years / systems
STD = {"Bakergonj": "Barisal", "Chittagonj": "Chittagong", "jamalpur": "Jamalpur", "Kustia": "Kushtia", "Khustia": "Kushtia",
       "Mymenshing": "Mymensingh", "Kishoregonj": "Kishoreganj", "Sunamgonj": "Sunamganj", "Hobigonj": "Habiganj",
       "Maulavibazar": "Moulvibazar", "Manikgonj": "Manikganj", "Munshigonj": "Munshiganj", "Munsigonj": "Munshiganj",
       "Narayangonj": "Narayanganj", "Gopalgonj": "Gopalganj", "Perojpur": "Pirojpur", "Noagaon": "Naogaon", "Nawabgonj": "Nawabganj",
       "Sirajgonj": "Sirajganj", "Jalakati": "Jhalokati", "Jhalakathi": "Jhalokati", "Gaibanda": "Gaibandha", "BANGLADESH": "Bangladesh"}
def std_name(n):
    n = re.sub(r"\s+", " ", n).strip()
    k = re.sub(r"[\s\.]", "", n).lower()
    if k == "chittagonght": return "Chittagong Hill Tracts"
    return STD.get(n, n)
df["year_start"] = df.fiscal_year.str[:4].astype(int)
df["has_split_cols"] = df.per_year == 6                    # Jute / Mesta / Total printed separately (<= 1988-89)

# ------------------------------------------------------------------ row types from the PDF's own hierarchy
df["row_type"] = "district"; df["sl"] = df.sl_no.fillna("")
df["region_printed"] = ""
for fy, g in df.groupby("fiscal_year", sort=False):
    g = g.sort_values("row_order"); acc = []
    for i, r in g.iterrows():
        n = r.district_raw.strip(); low = n.lower()
        if low.startswith("bangladesh"): df.at[i, "row_type"] = "national_total"; continue
        if r.year_start >= 2012:
            if re.fullmatch(r"0[1-7]", r.sl): df.at[i, "row_type"] = "division_subtotal"
            continue
        if 2004 <= r.year_start < 2012:
            if low.endswith("region"):
                if acc:
                    df.at[i, "row_type"] = "region_subtotal"
                    for j in acc: df.at[j, "region_printed"] = n.replace(" Region", "")
                else: df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["district_printed_as_single_district_region_row"]; df.at[i, "region_printed"] = n.replace(" Region", "")
                acc = []
            else: acc.append(i)
df["district_std"] = df.district_raw.map(std_name)
m = df.row_type == "region_subtotal"; df.loc[m, "district_std"] = df.loc[m, "district_std"].str.replace(" Region", "", regex=False) + " Region"
m = df.row_type == "division_subtotal"
df.loc[m, "district_std"] = df.loc[m, "district_std"].str.replace(" Region", " Division", regex=False)
m2 = (df.row_type == "district") & df.district_std.str.endswith(" Region")                       # singleton-region rows and the mislabelled 'Tangail Region'
df.loc[m2, "district_std"] = df.loc[m2, "district_std"].str.replace(" Region", "", regex=False)
flag((df.year_start >= 2012) & (df.district_raw == "Tangail Region"), "label_note_district_printed_with_Region_suffix")
df["district_std"] = df.district_std.map(lambda n: STD.get(n, n))
df["district_system"] = np.where(df.year_start < 1979, "20/21-district", np.where(df.year_start < 2004, "23-district", "64-district"))

# ------------------------------------------------------------------ geography: derived from the PDF, cross-checked with the 64->23 mapping used for the other crops
G23 = {
 "Bandarban": ["Bandarban"], "Chittagong": ["Chittagong", "Cox's Bazar"], "Comilla": ["Comilla", "Chandpur", "Brahmanbaria"],
 "Khagrachari": ["Khagrachari"], "Noakhali": ["Noakhali", "Lakshmipur", "Feni"], "Rangamati": ["Rangamati"],
 "Sylhet": ["Sylhet", "Moulvibazar", "Sunamganj", "Habiganj"],
 "Dhaka": ["Dhaka", "Gazipur", "Manikganj", "Munshiganj", "Narayanganj", "Narsingdi"],
 "Faridpur": ["Faridpur", "Rajbari", "Madaripur", "Gopalganj", "Shariatpur"], "Jamalpur": ["Jamalpur", "Sherpur"],
 "Kishoreganj": ["Kishoreganj", "Netrokona"], "Mymensingh": ["Mymensingh"], "Tangail": ["Tangail"],
 "Barisal": ["Barisal", "Jhalokati", "Pirojpur", "Bhola"], "Jessore": ["Jessore", "Jhenaidah", "Magura", "Narail"],
 "Khulna": ["Khulna", "Bagerhat", "Satkhira"], "Kushtia": ["Kushtia", "Chuadanga", "Meherpur"],
 "Patuakhali": ["Patuakhali", "Barguna"], "Bogra": ["Bogra", "Joypurhat"], "Dinajpur": ["Dinajpur", "Thakurgaon", "Panchagar"],
 "Pabna": ["Pabna", "Sirajganj"], "Rajshahi": ["Rajshahi", "Naogaon", "Natore", "Nawabganj"],
 "Rangpur": ["Rangpur", "Gaibandha", "Kurigram", "Nilphamari", "Lalmonirhat"]}
D2G = {d: g for g, ds in G23.items() for d in ds}; assert len(D2G) == 64
HILL = {"Bandarban", "Khagrachari", "Rangamati", "Chittagong Hill Tracts"}
# the PDF's own 'Region' rows (2004-05 .. 2011-12) are the legacy 23 districts -> compare
pdf_map = df[(df.row_type == "district") & (df.region_printed != "")][["district_std", "region_printed"]].drop_duplicates()
pdf_map["region_printed"] = pdf_map.region_printed.map(lambda n: STD.get(n, n))
mism = pdf_map[pdf_map.apply(lambda r: D2G.get(r.district_std) != r.region_printed, axis=1)]
print("64->23 mapping: districts whose PDF region differs from my mapping:", len(mism), "of", len(pdf_map)); print(mism.to_string())
assert len(mism) == 0
# divisions from the 2014-15 table (division rows follow their districts)
t = df[df.fiscal_year == "2014-15"].sort_values("row_order")
div, pend = {}, []
for _, r in t.iterrows():
    if r.row_type == "district": pend.append(r.district_std)
    elif r.row_type == "division_subtotal":
        for d in pend: div[d] = r.district_std.replace(" Division", "")
        pend = []
assert len(div) == 64, len(div)
G2DIV = {}
for g, ds in G23.items():
    s = {div[d] for d in ds}; assert len(s) == 1, (g, s); G2DIV[g] = s.pop()
def division_of(r):
    if r.row_type != "district": return np.nan
    if r.district_system == "64-district": return div[r.district_std]
    return G2DIV.get(r.district_std, "Chittagong" if r.district_std == "Chittagong Hill Tracts" else np.nan)
def group_of(r):
    if r.row_type != "district": return np.nan
    return D2G[r.district_std] if r.district_system == "64-district" else r.district_std
df["division"] = df.apply(division_of, axis=1); df["legacy_group_23"] = df.apply(group_of, axis=1)

# ------------------------------------------------------------------ clean columns
for c in RAW: df[f"{c}_clean"] = df[c].astype(float)
dist = df.row_type == "district"
df["label_repaired"] = False; df["label_repair_note"] = ""

# R1. 1987-88: Chittagong and Comilla rows carry each other's numbers (Comilla 20 acres vs Chittagong 53,045 acres)
i = df.index[(df.fiscal_year == "1987-88") & (df.district_std == "Chittagong") & dist][0]
j = df.index[(df.fiscal_year == "1987-88") & (df.district_std == "Comilla") & dist][0]
for c in RAW:
    a, b = df.at[i, f"{c}_clean"], df.at[j, f"{c}_clean"]; df.at[i, f"{c}_clean"], df.at[j, f"{c}_clean"] = b, a
for k, other in ((i, "Comilla"), (j, "Chittagong")):
    df.at[k, "label_repaired"] = True; df.at[k, "label_repair_note"] = f"values of printed row swapped with {other}"
    df.at[k, "dq_flags"] = df.at[k, "dq_flags"] + ["values_swapped_1987_88_chittagong_comilla"]

# R2. 1983-84 Chittagong: blank Jute production -> total production 310 minus mesta 0 (national total confirms it)
k = df.index[(df.fiscal_year == "1983-84") & (df.district_std == "Chittagong") & dist][0]
assert pd.isna(df.at[k, "jute_prod"]) and df.at[k, "total_prod"] == 310 and df.at[k, "mesta_prod"] == 0
df.at[k, "jute_prod_clean"] = 310.0; df.at[k, "dq_flags"] = df.at[k, "dq_flags"] + ["blank_jute_prod_filled_from_identity_total_minus_mesta"]

# R3. 1988-89: production is misaligned against area in the middle of the table (Dhaka .. Bogra) -> null production, keep area
blk = df.index[(df.fiscal_year == "1988-89") & dist & df.district_std.isin(
    ["Dhaka", "Faridpur", "Jamalpur", "Kishoreganj", "Mymensingh", "Tangail", "Barisal", "Jessore", "Khulna", "Kushtia", "Patuakhali", "Bogra", "Pabna"])]
assert len(blk) == 13
for k in blk:
    for c in ("jute_prod", "mesta_prod", "total_prod"): df.at[k, f"{c}_clean"] = np.nan
    df.at[k, "dq_flags"] = df.at[k, "dq_flags"] + ["suspect_unrecoverable_1988_89_production_misaligned_nulled"]
flag((df.fiscal_year == "1988-89") & dist & ~df.index.isin(blk), "note_1988_89_production_block_misaligned_neighbouring_rows")

# R4. typos in a single cell: neighbour-year yield test, digit shift repair (x10 / :10) or NULL
def nb_vals(i, v):
    r = df.loc[i]; out = []
    for dy in (-1, 1):
        j = df.index[(df.district_std == r.district_std) & (df.district_system == r.district_system) & (df.year_start == r.year_start + dy) & (df.row_type == "district")]
        if len(j):
            a, p = df.at[j[0], f"{v}_area"], df.at[j[0], f"{v}_prod"]
            if pd.notna(a) and pd.notna(p) and a > 0 and p > 0 and not (df.at[j[0], "fiscal_year"] == "1988-89"): out.append((a, p))
    if len(out) == 2 and abs(np.log((out[0][1] / out[0][0]) / (out[1][1] / out[1][0]))) > 0.25: return []
    return out
repairs = []
for v in ("jute", "total"):
    a, p = f"{v}_area_clean", f"{v}_prod_clean"
    sel = dist & df[a].notna() & df[p].notna() & (df[a] > 0)
    y = df[p] / df[a].where(df[a] > 0)
    med = y[dist].groupby(df.fiscal_year[dist]).median(); rel = y / df.fiscal_year.map(med)
    for i in df.index[sel]:
        if v == "jute" and not df.at[i, "has_split_cols"]: continue
        if v == "total" and df.at[i, "has_split_cols"]: continue               # in split years the total is jute+mesta (recomputed below)
        A, P = df.at[i, a], df.at[i, p]
        if A < 1000: continue
        nbs = nb_vals(i, v); yi = P / A
        copy = (P == A)                                                           # production typed equal to area
        extreme = (rel[i] < 0.3) or (rel[i] > 3.0) or copy
        anomaly = False
        if nbs and A >= 3000:
            nby = np.mean([pp / aa for aa, pp in nbs])
            if not (0.5 <= yi / nby <= 1.8):
                dA = min(abs(np.log(A / aa)) for aa, _ in nbs); dP = min(abs(np.log(P / pp)) for _, pp in nbs)
                anomaly = max(dA, dP) > 0.35 and min(dA, dP) < 0.25
        if not (extreme or anomaly): continue
        dA = min(abs(np.log(A / aa)) for aa, _ in nbs) if nbs else 0; dP = min(abs(np.log(P / pp)) for _, pp in nbs) if nbs else 0
        which = "area" if dA > dP else "prod"
        ref = np.mean([pp / aa for aa, pp in nbs]) if nbs else float(med[df.at[i, "fiscal_year"]])
        opts = [("area_x10", A * 10, P), ("area_div10", A / 10, P)] if which == "area" else [("prod_x10", A, P * 10), ("prod_div10", A, P / 10)]
        good = []
        for lab, na, np_ in opts:
            if na != int(na) or np_ != int(np_): continue
            if not (0.6 * ref <= np_ / na <= 1.5 * ref): continue
            val, nbq = (na, [aa for aa, _ in nbs]) if which == "area" else (np_, [pp for _, pp in nbs])
            good.append((min(abs(np.log(val / n)) for n in nbq) if nbq else np.inf, lab, na, np_))
        good.sort()
        if good and good[0][0] < np.log(1.3):
            _, lab, na, np_ = good[0]; df.at[i, a], df.at[i, p] = na, np_
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"adj_{v}_{lab}"]; repairs.append((df.at[i, "fiscal_year"], df.at[i, "district_std"], v, lab, A, P, na, np_))
        else:
            df.at[i, a] = np.nan; df.at[i, p] = np.nan
            df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"suspect_unrecoverable_{v}_nulled"]; repairs.append((df.at[i, "fiscal_year"], df.at[i, "district_std"], v, "NULLED", A, P, np.nan, np.nan))
rep_tbl = pd.DataFrame(repairs, columns=["fy", "district", "variety", "action", "area_raw", "prod_raw", "area_clean", "prod_clean"])
print(rep_tbl.to_string())

# totals in split years = jute + mesta (NaN propagates); single-series years keep their (cleaned) printed total
for q in ("area", "prod"):
    s = df[f"jute_{q}_clean"] + df[f"mesta_{q}_clean"]
    df.loc[df.has_split_cols, f"total_{q}_clean"] = s[df.has_split_cols]
df["chk_area_printed_minus_calc"] = np.where(df.has_split_cols, df.total_area - (df.jute_area + df.mesta_area), np.nan)
df["chk_prod_printed_minus_calc"] = np.where(df.has_split_cols, df.total_prod - (df.jute_prod + df.mesta_prod), np.nan)

# ------------------------------------------------------------------ aggregates (clean): regions, divisions, national
cols = [f"{v}_{q}" for v in VARS for q in ("area", "prod")]
FILL = {c: df[f"{c}_clean"].where(df[f"{c}_clean"].notna(), df[c]) for c in cols}
def agg_set(sel, i):
    for c in cols:
        if c.startswith(("jute", "mesta")) and not df.at[i, "has_split_cols"]: continue
        df.at[i, f"{c}_clean"] = FILL[c][sel].sum() if FILL[c][sel].notna().any() else np.nan
for fy in df.fiscal_year.unique():
    g = df[df.fiscal_year == fy]
    sel = dist & (df.fiscal_year == fy)
    ni = g.index[g.row_type == "national_total"]; assert len(ni) == 1, fy
    agg_set(sel, ni[0])
    for i in g.index[g.row_type == "division_subtotal"]:
        dn = df.at[i, "district_std"].replace(" Division", ""); agg_set(sel & (df.division == dn), i)
    for i in g.index[g.row_type == "region_subtotal"]:
        rn = df.at[i, "district_std"].replace(" Region", ""); agg_set(sel & (df.region_printed.map(lambda n: STD.get(n, n)) == rn), i)
for rt, tag in (("national_total", "national"), ("division_subtotal", "division"), ("region_subtotal", "region")):
    for i in df.index[df.row_type == rt]:
        for c in cols:
            pv, cv = df.at[i, c], df.at[i, f"{c}_clean"]
            if pd.notna(pv) and pd.notna(cv) and abs(pv - cv) > 1:
                df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + [f"src_{tag}_printed_{c}_differs_from_district_sum"]

# ------------------------------------------------------------------ source-level notes
yy = df.fiscal_year.isin(["2001-02", "2002-03"])
flag(yy, "src_production_identical_in_2001_02_and_2002_03_one_year_is_a_copy")
flag(~df.has_split_cols, "note_single_series_1989_90_on_assumed_jute_incl_mesta")
flag(df.year_start >= 2012, "note_production_header_says_M_tons_but_values_are_bales")
flag(dist & (df.district_std == "Rangamati") & df.fiscal_year.isin(["1981-82", "1982-83", "1983-84"]), "note_cht_probably_included_in_rangamati_assumed")
flag(df.dq_flags.apply(lambda f: "last_col_cell_merged" in f), "note_cell_fragments_rejoined")

# ------------------------------------------------------------------ yields
def add_yields(d):
    pa = lambda p, a: np.where(d[a] > 0, d[p] / d[a], np.nan)
    d["yield_total_bales_per_acre"] = pa("total_prod_clean", "total_area_clean")
    d["yield_jute_bales_per_acre"] = pa("jute_prod_clean", "jute_area_clean")
    d["yield_mesta_bales_per_acre"] = pa("mesta_prod_clean", "mesta_area_clean")
    return d
df = add_yields(df)
dd = df[dist & (df.total_area_clean >= 1000)]
med = dd.groupby("fiscal_year").yield_total_bales_per_acre.median(); rel = dd.yield_total_bales_per_acre / dd.fiscal_year.map(med)
for i in dd.index[(rel < 0.3) | (rel > 3.0)]: df.at[i, "dq_flags"] = df.at[i, "dq_flags"] + ["yield_outlier_review"]
df["is_cultivated"] = df.total_area_clean > 0
df["dq_flags_str"] = df.dq_flags.apply(lambda f: ";".join(sorted(set(f))))
df["record_id"] = df.source_table + "|" + df.fiscal_year + "|" + df.district_raw.str.replace(r"\s+", "_", regex=True) + "|" + df.row_order.astype(str)

CLEAN = [f"{c}_clean" for c in cols]
MASTER_COLS = (["record_id", "source_table", "source_pdf_page", "sl_no", "fiscal_year", "year_start", "district_raw", "district_std",
                "label_repaired", "label_repair_note", "row_type", "district_system", "division", "legacy_group_23", "region_printed",
                "has_split_cols"] + RAW + ["chk_area_printed_minus_calc", "chk_prod_printed_minus_calc"] + CLEAN +
               ["yield_total_bales_per_acre", "yield_jute_bales_per_acre", "yield_mesta_bales_per_acre", "is_cultivated", "dq_flags_str"])
master = df[MASTER_COLS].copy()
for c in RAW + ["chk_area_printed_minus_calc", "chk_prod_printed_minus_calc"]: master[c] = master[c].astype("Int64")
for c in CLEAN: master[c] = master[c].round(0).astype("Int64")
master.to_csv(f"{OUT}/jute_master_long.csv", index=False)
aud.rename(columns={"table": "source_table", "pdf_page": "source_pdf_page", "name": "row_name_raw"}).to_csv(f"{OUT}/jute_raw_cells_audit.csv", index=False)

# ------------------------------------------------------------------ ML features
def features(d, ent, nat):
    d = d.sort_values(ent + ["year_start"]).reset_index(drop=True)
    d["split_recorded"] = (d.year_start <= 1988).astype(int)
    ta = d.total_area.where(d.total_area > 0)
    d["mesta_area_share"] = d.mesta_area / ta; d["jute_area_share"] = d.jute_area / ta
    d["yield_total_bales_per_acre"] = np.where(d.total_area > 0, d.total_prod / d.total_area, np.nan)
    d["yield_jute_bales_per_acre"] = np.where(d.jute_area > 0, d.jute_prod / d.jute_area, np.nan)
    d["yield_mesta_bales_per_acre"] = np.where(d.mesta_area > 0, d.mesta_prod / d.mesta_area, np.nan)
    d["area_ha"] = d.total_area * 0.40468564224
    d = d.merge(nat, on="year_start", how="left")
    d["area_share_of_national"] = d.total_area / d.nat_total_area
    d["prod_share_of_national"] = d.total_prod / d.nat_total_prod
    d["yield_vs_national"] = d.yield_total_bales_per_acre / d.nat_yield_total_bales_per_acre
    d["_seg"] = (d.groupby(ent).year_start.diff().fillna(1) != 1).groupby([d[e] for e in ent]).cumsum()
    g = d.groupby(ent + ["_seg"], sort=False)
    for c in ["total_area", "total_prod", "yield_total_bales_per_acre"]:
        s = g[c]; d[f"{c}_lag1"] = s.shift(1); d[f"{c}_lag2"] = s.shift(2)
        d[f"{c}_roll3_prev_mean"] = s.transform(lambda x: x.shift(1).rolling(3, min_periods=1).mean())
        d[f"{c}_yoy_pct"] = np.where(d[f"{c}_lag1"] > 0, (d[c] / d[f"{c}_lag1"] - 1) * 100, np.nan)
    d["entity_hist_mean_yield"] = g["yield_total_bales_per_acre"].transform(lambda x: x.shift(1).expanding().mean())
    d["t_index"] = d.year_start - d.year_start.min(); d["decade"] = (d.year_start // 10) * 10
    d["post_liberation"] = (d.year_start >= 1971).astype(int)
    d["target_total_prod_next_year"] = g["total_prod"].shift(-1)
    d["target_yield_next_year"] = g["yield_total_bales_per_acre"].shift(-1)
    d["entity_id"] = d[ent].astype(str).agg("|".join, axis=1)
    return d.drop(columns="_seg")

nr = df[df.row_type == "national_total"].drop_duplicates("year_start")
nat = pd.DataFrame({"year_start": nr.year_start, "nat_total_area": nr.total_area_clean, "nat_total_prod": nr.total_prod_clean})
nat["nat_yield_total_bales_per_acre"] = nat.nat_total_prod / nat.nat_total_area
ren = {f"{c}_clean": c for c in cols}
d0 = df[dist][["record_id", "fiscal_year", "year_start", "district_system", "district_std", "division", "legacy_group_23", "source_table",
               "label_repaired", "is_cultivated", "dq_flags_str"] + CLEAN].rename(columns=ren)
ml = features(d0, ["district_system", "district_std"], nat)
ML_COLS = ["record_id", "entity_id", "fiscal_year", "year_start", "t_index", "decade", "post_liberation", "district_system", "district_std",
           "division", "legacy_group_23", "source_table", "label_repaired", "split_recorded",
           "jute_area", "jute_prod", "mesta_area", "mesta_prod", "total_area", "area_ha", "total_prod", "jute_area_share", "mesta_area_share",
           "yield_total_bales_per_acre", "yield_jute_bales_per_acre", "yield_mesta_bales_per_acre",
           "nat_total_area", "nat_total_prod", "nat_yield_total_bales_per_acre", "area_share_of_national", "prod_share_of_national", "yield_vs_national",
           "total_area_lag1", "total_area_lag2", "total_area_roll3_prev_mean", "total_area_yoy_pct",
           "total_prod_lag1", "total_prod_lag2", "total_prod_roll3_prev_mean", "total_prod_yoy_pct",
           "yield_total_bales_per_acre_lag1", "yield_total_bales_per_acre_lag2", "yield_total_bales_per_acre_roll3_prev_mean", "yield_total_bales_per_acre_yoy_pct",
           "entity_hist_mean_yield", "is_cultivated", "dq_flags_str", "target_total_prod_next_year", "target_yield_next_year"]
ml[ML_COLS].to_csv(f"{OUT}/jute_ml_ready_district_panel.csv", index=False)

# ------------------------------------------------------------------ harmonised panel 1981-82 .. 2014-15 (21 groups; hill tracts merged)
base = d0[d0.district_system != "20/21-district"].copy()
base["panel_group"] = base.legacy_group_23.where(~base.legacy_group_23.isin(HILL), "Chittagong Hill Tracts")
vals = cols
def smin(x): return x.sum(min_count=len(x))                                      # NaN anywhere inside the group -> NaN
agg = (base.groupby(["panel_group", "fiscal_year", "year_start"], as_index=False)
       .agg(**{c: (c, smin) for c in vals}, n_components=("district_std", "nunique"), src_system=("district_system", "first"),
            flags=("dq_flags_str", lambda s: ";".join(sorted({f for x in s for f in str(x).split(";") if f and f != "nan"})))))
agg["district_std"] = agg.panel_group; agg["district_system"] = "21-group-harmonised"; agg["legacy_group_23"] = agg.panel_group
agg["division"] = agg.panel_group.map(lambda g: "Chittagong" if g == "Chittagong Hill Tracts" else G2DIV[g])
agg["is_aggregated_from_64"] = agg.src_system == "64-district"
agg["source_table"] = ""; agg["label_repaired"] = False; agg["record_id"] = "P21|" + agg.fiscal_year + "|" + agg.panel_group
agg["is_cultivated"] = agg.total_area > 0; agg["dq_flags_str"] = agg.flags
pan = features(agg, ["district_system", "district_std"], nat)
PCOLS = [c for c in ML_COLS if c in pan.columns] + ["n_components", "is_aggregated_from_64"]
pan[PCOLS].to_csv(f"{OUT}/jute_panel_21groups_1981_2015.csv", index=False)

# ------------------------------------------------------------------ report
print("rows master/ml/panel:", len(master), len(ml), len(pan))
print(master.dq_flags_str.str.split(";").explode().replace("", np.nan).dropna().value_counts().to_string())
nb = sum(sum(1 for v in json.loads(s) if v != "") for s in aud.raw_cells)
print("non-blank raw cells:", nb, "| printed values in master (per year-row):", int(master[RAW].notna().sum().sum()))
df.to_pickle("/tmp/jute_final.pkl"); rep_tbl.to_pickle("/tmp/jute_repairs.pkl")
