# Jute – Bangladesh (BBS "45 Years Agriculture Statistics", Tables 2.1 – 2.14)

Area in **acres**, production in **bales**. Rebuild with `python build_jute_dataset.py` (needs `parse_jute.py`, `parse_amon.py`). Column meanings as in README_data_dictionary.md.

| File | Rows | Use |
|---|---|---|
| `jute_ml_ready_district_panel.csv` | 1,433 | **Main ML file** – district rows, features, lags, targets |
| `jute_panel_21groups_1981_2015.csv` | 714 | 21 consistent regions × 34 years (64 districts folded into the old 23, hill tracts merged) |
| `jute_master_long.csv` | 1,642 | everything printed: 1,433 districts, 144 regional subtotals (18 multi-district regions × 8 years, 2004-05 → 2011-12), 21 division subtotals (2012-13 → 2014-15), 44 national rows; printed + `*_clean` values + flags |
| `jute_raw_cells_audit.csv` | 490 | every PDF row as extracted |

## What is different about this PDF
* **Two years are not in the PDF at all: 1979-80 and 1980-81** (Table 2.4 ends at 1978-79, Table 2.5 starts at 1981-82). 44 of the 46 years are present; I did not invent them. Lags never cross that gap.
* **Varieties:** Jute, Mesta and Total are printed separately only for 1969-70 → 1988-89 (Total = Jute + Mesta holds in every row). From 1989-90 one series per year is printed, and the "Jute / Mesta / Total" labels on those pages are leftover header text. I treat it as the all-jute figure (it continues smoothly from the 1988-89 Total: 1.31M → 1.34M acres); mesta was about 1% of area, so the assumption is small but not proven. Those rows carry `note_single_series_1989_90_on_assumed_jute_incl_mesta`; `split_recorded` = 0 and jute/mesta columns are blank.
* **Units:** 2012-13 → 2014-15 are headed "Production M tons", but the values are bales (4.5 per acre, the same scale as 2011-12; metric tons would be 11 t/ha). Flagged; the column is bales throughout.
* **Hierarchy:** 2004-05 → 2011-12 list districts under "Regions", which are exactly the old 23 districts; 2012-13 → 2014-15 list districts under divisions. Every region/division subtotal equals the sum of its districts, and districts equal the printed national total in every year except 1985-86 (below). My 64→23 district mapping matched the PDF's own regions for all 64 districts.
* Single-district regions (Bandarban, Khagrachari, Rangamati, Mymensingh, Tangail) have no separate district row, so the region row is used as the district (`district_printed_as_single_district_region_row`). "Tangail Region" in 2012-15 is the district.

**Reconciliation:** 4,932 non-blank PDF cells → 4,891 values; the 41 extra cells are numbers the PDF split across two cells (re-joined; the Jute+Mesta=Total identity confirms every merge).

## Problems in the source (all in `dq_flags_str`; printed values are never edited)
| Issue | Handling |
|---|---|
| 1987-88: Chittagong and Comilla rows carry each other's numbers (Comilla 20 acres, Chittagong 53,045) | swapped in `*_clean` (matches both neighbouring years) |
| 1988-89: production is misaligned against area for 13 districts (Dhaka … Pabna; yields of 0.04 to 265 bales/acre). No re-alignment was reliable | production set to NULL in `*_clean` for those 13 rows; area kept |
| 1983-84 Chittagong: blank Jute production | filled = Total 310 − Mesta 0 (the national total confirms 310) |
| 1985-86: printed national production is 29,961 bales higher than the district sum; no single district stands out | left unresolved, flagged on the national row |
| 2001-02 and 2002-03 production is identical in all 20 non-zero districts (and nationally, 4,407,800) while area differs – one year is a copy | **kept and flagged on both years**; decide yourself which to trust or drop |
| Typos: Comilla 1977-78 (production 867,915 on 80,455 acres), Sylhet 1977-78 (production typed equal to area), Rajshahi 1975-76 (yield 0.6 vs ~2.8) | cells set to NULL in `*_clean` |
| 1981-82 → 1983-84 Rangamati is probably carrying all Hill-Tract jute (as in the other crops); not printed in this PDF | flagged as an assumption; use the 21-group panel |

## Modelling notes
Yield is in bales/acre (`yield_total_bales_per_acre`). The district system changes three times (20 → 23 → 64 districts); lags do not cross a change or a year gap. Use time-based splits. Missing values are left as NaN (1988-89 production, the three NULLed cells, and yields where area is 0).
