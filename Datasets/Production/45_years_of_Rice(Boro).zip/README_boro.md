# Boro rice (husked rice) – Bangladesh (BBS "45 Years Agriculture Statistics", Tables 1.3.1 – 1.3.46)

46 fiscal years (1969-70 → 2014-15), area in acres, production in tons (printed "tons" and "M.tons" interchangeably = metric tons).
Rebuild with `python build_boro_dataset.py` (needs `parse_boro.py`, `parse_amon.py`). Column meanings as in README_data_dictionary.md.

| File | Rows | Use |
|---|---|---|
| `boro_rice_ml_ready_district_panel.csv` | 1,399 | **Main ML file** |
| `boro_rice_panel_21groups_1979_2015.csv` | 756 | 21 consistent regions × 36 years (Hill-Tract districts merged) |
| `boro_rice_master_long.csv` | 1,477 | everything printed: 1,399 districts, 28 division subtotals, 46 national rows, 3 duplicate rows, 1 junk row; printed + `*_clean` values + flags |
| `boro_rice_raw_cells_audit.csv` | 1,477 | every PDF row as extracted |

**Varieties:** Local, HYV, Pajam (separate column 1976-77 → 1997-98 only; before that and from 1998-99 inside HYV), Hybrid (separate column from 2006-07, but 2006-07 hybrid is printed as 0 because it was included in HYV – effectively recorded from 2007-08; see `hybrid_recorded`). Table 1.3.17's header says "Local Transplant" – a typo for Local.
**Reconciliation:** 11,133 non-blank PDF cells → 11,136 values (3 rows where the grid had a blank/merged cell and the page text supplied the value). Printed Total = sum of printed parts in every row except Bandarban 2003-04 and the national row that inherits it. District sums = printed national totals in every year except 2006-07 and 2014-15 (below).

## Problems in the source PDF (all in `dq_flags_str`; printed values are never edited)
| Issue | Handling |
|---|---|
| 2006-07: Dinajpur, Thakurgaon, Panchagar printed twice (inside the Rajshahi block and the Rangpur block). Printed Rajshahi-division total includes them and the printed national row (20,613,320 acres) is roughly double the district sum | first copies kept as `row_type=duplicate_row` (excluded from ML); division and national totals recomputed from districts |
| 2014-15: 23 rows carry the wrong label (labels shifted one row in the Dhaka/Mymensingh and Barisal/Khulna stretches; a division total printed in a district slot; "Khustia" row is a copy of Bandarban's numbers) | relabelled. **Verified exactly:** the 64 districts add up to the national total area and every one of the 7 division rows equals the sum of its districts (Barisal 361,086; Khulna 1,455,306; Dhaka incl. Mymensingh 3,619,419). The new 8th division (Mymensingh) is not printed separately – the PDF's "Dhaka" figure covers both |
| 2012-13 "Dhaka Division" label garbled ("2121") | inferred from serial 03 (values match the sum of its 17 districts) |
| Bandarban 2003-04 Total area printed 0 | filled from components (4,500) |
| Typos | Sylhet 1973-74 HYV prod ×10 and Rangamati 1989-90 HYV prod ÷10 repaired (match neighbouring years). Set to NULL in `*_clean`: Noakhali 1979-80, Bogra 1989-90, Chittagong 1990-91, Rangpur 1993-94 (HYV); Mymensingh 1987-88, Tangail 1994-95, Kishoreganj 1998-99, Chandpur 2008-09, Khagrachari 2008-09 (Local) |
| Jamalpur is zero before 1978-79 (part of Mymensingh); Hill-Tract figures 1979-80 → 1983-84 printed against Rangamati | flagged `structural_zero_*` / `src_note_cht_*`; use the 21-group panel for continuity |
2013-14 needed no relabelling (ratio of each district to its neighbouring years is 0.92-1.07 except tiny Barguna/Rangamati/Jhalokati).

## Modelling notes
Boro is estimated and very volatile in the 1970s (round numbers, e.g. Sylhet 1976-77), and area expanded several-fold – use time-based splits, and consider starting training at 1979-80. Lags never cross a system change or a gap in years.
