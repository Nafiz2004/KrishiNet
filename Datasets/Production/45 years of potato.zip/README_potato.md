# Potato – Bangladesh (BBS "45 Years Agriculture Statistics", Tables 3.1 – 3.33)

All 46 years are present (1969-70 → 2014-15). Area in **acres**, production in **metric tons** (printed "M tons"); yields in t/acre and kg/ha.
Rebuild with `python build_potato_dataset.py` (needs `parse_potato.py`). Column meanings as in README_data_dictionary.md.

| File | Rows | Use |
|---|---|---|
| `potato_ml_ready_district_panel.csv` | 1,523 | **Main ML file** |
| `potato_panel_21groups_1979_2015.csv` | 756 | 21 consistent regions × 36 years (64 districts folded into the old 23; hill tracts merged) |
| `potato_master_long.csv` | 1,764 | everything printed: 1,523 districts, 180 regional subtotals (18 multi-district regions × 10 years, 2003-04 → 2012-13), 15 division subtotals (2013-14: 7, 2014-15: 8), 46 national rows; printed + `*_clean` values + flags |
| `potato_raw_cells_audit.csv` | 1,152 | every PDF row as extracted |

## Layout by era
* 1969-70 → 1981-82: one series only (area, production) – stored as `total_*`; `variety_split_recorded` = 0.
* 1982-83 → 2002-03: Local, HYV, **Indian** (imported varieties), Total.
* 2003-04 → 2014-15: Local, HYV, Total (no Indian column).
* 2003-04 → 2012-13 list districts under "Regions" = the old 23 districts (my 64→23 mapping matched the PDF's own regions in every case); 2013-14 uses 7 divisions, 2014-15 the new 8 (Mymensingh Division split from Dhaka). Single-district regions (Bandarban, Khagrachari, Rangamati, Mymensingh, Tangail) are printed as one row and used as districts.
* **Reconciliation:** 10,453 non-blank PDF cells → 10,451 values (2 numbers split over two cells were rejoined). Total = sum of varieties in every printed row except those listed below.

## Problems in the source (all in `dq_flags_str`; printed values are never edited)
| Issue | Handling |
|---|---|
| **2013-14, Chittagong, Sylhet and Dhaka divisions (32 districts + 3 division rows): Local, HYV and Total do not add up and do not match 2012-13 / 2014-15** (checked against the raw page text – the PDF itself is inconsistent). The Barisal, Khulna, Rajshahi and Rangpur blocks are fine | variety and total values set to NULL in `*_clean` for those 35 rows; the printed national row for 2013-14 (internally consistent) is kept |
| 2003-04 and 2004-05 are identical in every row (incl. national); 1993-94 and 1994-95 are identical in all 23 districts | kept and flagged on both years; one year in each pair is a copy – decide which to trust |
| 1970-71 Dhaka (391,005) and Kishoreganj (82,005) area have a stray trailing "5" (true ≈ 39,100 and 8,200); the printed national area (639,605) was summed from them | repaired; clean national 213,895 |
| 1983-84 Rajshahi Indian production 102,100 is 10× too high (yield 27 t/acre); printed national total production includes it | ÷10 → 10,210 (matches 1982-83 yields) |
| Single-cell typos with no safe repair: Rajshahi 1988-89 local, Barisal 1988-89 HYV, Faridpur 1972-73 total, Dinajpur 1992-93 local, Bogra 2008-09 local, Kushtia 1995-96 HYV | cells set to NULL in `*_clean` (evidence: both neighbouring years disagree with the printed cell) |
| 2009-10 Patuakhali / Barguna: printed Total areas are 10,480 / 1,673 although varieties and the region row agree with 1,673 / 2,768 | total recomputed from the varieties |
| Printed national rows inconsistent: 2006-07 total production (5,166,672 vs Local+HYV 5,166,769), 2008-09 HYV production, 2014-15 Local/HYV do not add to Total | clean national = sum of districts |
| Rangpur 2001-02 Indian production is blank | left NULL (Indian area is 0) |
| Hill-Tract figures probably sit under Rangamati for 1979-80 → 1983-84 (as the book states for other crops; not printed here) | flagged as an assumption |

## Modelling notes
Yields are 2-3× higher in HYV than in Local; use `hyv_area_share` as a feature. Missing values stay NaN (the 2013-14 block, six NULLed cells, yields where area = 0, first-year lags, last-year targets). Lags never cross a system change or year gap. Use time-based splits.
