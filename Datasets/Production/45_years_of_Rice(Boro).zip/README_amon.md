# Amon (Aman) rice – Bangladesh (BBS "45 Years Agriculture Statistics", Tables 1.2.1 – 1.2.41)

46 fiscal years (1969-70 → 2014-15), area in acres, production in tons. Same file layout as the Aus set
(see README_data_dictionary.md for column meanings); rebuild with `python build_amon_dataset.py` (needs `parse_amon.py`).

| File | Rows | Use |
|---|---|---|
| `amon_rice_ml_ready_district_panel.csv` | 1,400 | **Main ML file** – district rows, features, lags, targets |
| `amon_rice_panel_21groups_1979_2015.csv` | 756 | 21 consistent regions × 36 years (64 districts folded back into the 23 old ones; the three Hill-Tract districts merged into one group) |
| `amon_rice_master_long.csv` | 1,467 | everything printed (1,400 districts, 21 division subtotals, 46 national rows) + printed and `*_clean` values + flags |
| `amon_rice_raw_cells_audit.csv` | 1,404 | every PDF row as extracted |

**Varieties:** Broadcast Aman (`bcast`), Local Transplant (`ltrans`), HYV, Pajam (separate column only 1977-78 → 1998-99; otherwise inside HYV), Total.
**Reconciliation:** 12,777 non-blank PDF cells → 12,781 values (4 national rows whose last grid cell was blank; the value was read from the page text). Printed Total = sum of printed parts in every row except Kushtia 1977-78 (blank cell) and two national rows (1977-78, 2014-15). District sums = printed national totals in every year except 2014-15 (label scramble, below).

## Problems in the source PDF (all in `dq_flags_str`; printed values are never edited)
| Issue | Handling |
|---|---|
| 2014-15: labels in the Rajshahi/Rangpur block shifted by one row; the "Nawabgonj" row is really the Rajshahi-division total and the "Rajshahi Division" row is Dinajpur | relabelled (10 rows). **Verified exactly:** both division totals equal the sum of their districts and the 64 districts add to the national total area |
| 2013-14: rows rotated in the Barisal/Khulna block (12 rows) and permuted in the Rajshahi/Rangpur block (9 rows); printed division totals were built on the scrambled rows | relabelled by similarity to 2012-13/2014-15 (area and variety mix). 4 rows are `..._medium_confidence`. Division totals recomputed |
| 2010-11: Broadcast production column is shifted up one row from Jhalakathi to the end (31 rows) | shifted back in `bcast_prod_clean`; every broadcast yield is then plausible (0.2-0.9) and the column still sums to the printed national value |
| Digit slips: Jessore 1970-71 (bcast prod ×10), Dinajpur 1971-72 (bcast area ÷10), Jessore 1995-96 (ltrans area ÷10), Chittagong 1995-96 (hyv area ×10) | repaired in `*_clean` only when the repaired value matches neighbouring years |
| Unrecoverable: Rangamati 1979-80 HYV, Tangail 1994-95 Local Transplant | cells set to NULL in `*_clean` |
| Kushtia 1977-78 Total area blank; printed national total area for that year omits it | filled from components (158,780) |
| 2014-15 national HYV area is printed wrong (6,876,352) | clean national = sum of districts |
| Jamalpur (1976-79) is part of Mymensingh before 26-12-78; Hill-Tract figures for 1979-80 → 1983-84 are printed against Rangamati (Bandarban/Khagrachari zero) | flagged `structural_zero_*`, `src_note_cht_*`; use the 21-group panel for continuity |
Judgement calls to double-check against the original book: the 2013-14 relabelling (inferred) and the digit repairs.

## Columns (ML file) – differences from Aus
`bcast_*`, `ltrans_*`, `local_*` (= bcast+ltrans), `hyv_*`, `pajam_*`, `hyv_incl_pajam_*`, shares `bcast_/ltrans_/hyv_area_share`, yields (total, bcast, ltrans, hyv), national context `nat_*`, lags/rolling/yoy (past-only), `target_total_prod_next_year`, `target_yield_next_year`. Lags never cross a district-system change (20/21 → 23 → 64 districts) or a gap in years.
